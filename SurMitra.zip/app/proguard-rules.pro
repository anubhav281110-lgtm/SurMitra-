# Add project specific ProGuard rules here.

# Retrofit / OkHttp / Gson — keep model classes used for JSON (de)serialization.
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.surmitra.music.data.remote.** { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**

# Room
-keep class com.surmitra.music.data.local.** { *; }

# Media3
-dontwarn androidx.media3.**
