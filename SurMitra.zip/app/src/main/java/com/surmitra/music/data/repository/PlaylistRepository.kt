package com.surmitra.music.data.repository

import com.surmitra.music.data.local.CachedSongEntity
import com.surmitra.music.data.local.FavouriteEntity
import com.surmitra.music.data.local.HistoryEntity
import com.surmitra.music.data.local.PlaylistEntity
import com.surmitra.music.data.local.PlaylistSongEntity
import com.surmitra.music.data.local.SurMitraDatabase
import com.surmitra.music.data.model.PlaylistSummary
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.model.TrackSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * Playlists, favourites and history all reference songs by id only. A song's
 * full metadata is cached here the moment it's added to any of the three, so
 * these lists render correctly even for online tracks that aren't currently
 * in a fetched catalog page, and even offline.
 */
class PlaylistRepository(
    database: SurMitraDatabase,
    private val libraryRepository: MusicLibraryRepository
) {
    private val playlistDao = database.playlistDao()
    private val favouriteDao = database.favouriteDao()
    private val historyDao = database.historyDao()
    private val cachedSongDao = database.cachedSongDao()

    // --- Playlists ---------------------------------------------------------

    suspend fun createPlaylist(name: String): Long =
        playlistDao.insertPlaylist(PlaylistEntity(name = name, createdAt = System.currentTimeMillis()))

    suspend fun renamePlaylist(id: Long, name: String) = playlistDao.renamePlaylist(id, name)

    suspend fun deletePlaylist(id: Long) {
        playlistDao.clearPlaylistSongs(id)
        playlistDao.deletePlaylist(id)
    }

    fun observePlaylistSummaries(): Flow<List<PlaylistSummary>> =
        playlistDao.observePlaylists().map { entities ->
            entities.map { entity ->
                PlaylistSummary(
                    id = entity.id,
                    name = entity.name,
                    songCount = playlistDao.songCountForPlaylist(entity.id),
                    createdAt = entity.createdAt
                )
            }
        }

    suspend fun addSongToPlaylist(playlistId: Long, song: Song) {
        cacheSong(song)
        val position = playlistDao.nextPosition(playlistId)
        playlistDao.addSongToPlaylist(PlaylistSongEntity(playlistId = playlistId, songId = song.id, position = position))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: String) =
        playlistDao.removeSongFromPlaylist(playlistId, songId)

    fun observeSongsForPlaylist(playlistId: Long): Flow<List<Song>> =
        playlistDao.observeSongIdsForPlaylist(playlistId).map { resolveSongs(it) }

    // --- Favourites ----------------------------------------------------------

    fun observeIsFavourite(songId: String): Flow<Boolean> = favouriteDao.observeIsFavourite(songId)

    suspend fun toggleFavourite(song: Song) {
        val isFavourite = favouriteDao.observeIsFavourite(song.id).first()
        if (isFavourite) {
            favouriteDao.delete(song.id)
        } else {
            cacheSong(song)
            favouriteDao.insert(FavouriteEntity(songId = song.id, addedAt = System.currentTimeMillis()))
        }
    }

    fun observeFavourites(): Flow<List<Song>> =
        favouriteDao.observeFavouriteIds().map { resolveSongs(it) }

    // --- History -------------------------------------------------------------

    suspend fun recordPlayed(song: Song) {
        cacheSong(song)
        historyDao.insert(HistoryEntity(songId = song.id, playedAt = System.currentTimeMillis()))
    }

    fun observeRecentlyPlayed(limit: Int = 20): Flow<List<Song>> =
        historyDao.observeRecentSongIds(limit).map { resolveSongs(it) }

    // --- Shared resolution -----------------------------------------------------

    private suspend fun cacheSong(song: Song) = cachedSongDao.upsert(song.toCachedEntity())

    private suspend fun resolveSongs(ids: List<String>): List<Song> {
        if (ids.isEmpty()) return emptyList()
        val fromLibrary = ids.mapNotNull { libraryRepository.findById(it) }
        val resolvedIds = fromLibrary.map { it.id }.toSet()
        val remainingIds = ids.filterNot { it in resolvedIds }
        val cached = if (remainingIds.isEmpty()) emptyList() else cachedSongDao.getByIds(remainingIds).map { it.toSong() }
        val byId = (fromLibrary + cached).associateBy { it.id }
        return ids.mapNotNull { byId[it] }
    }
}

private fun Song.toCachedEntity() = CachedSongEntity(
    id = id, title = title, artist = artist, album = album, albumArtUri = albumArtUri,
    durationMs = durationMs, source = source.name, streamUri = streamUri, genre = genre,
    isDownloadAllowed = isDownloadAllowed, localFormat = localFormat
)

private fun CachedSongEntity.toSong() = Song(
    id = id, title = title, artist = artist, album = album, albumArtUri = albumArtUri,
    durationMs = durationMs, source = TrackSource.valueOf(source), streamUri = streamUri,
    genre = genre, isDownloadAllowed = isDownloadAllowed, localFormat = localFormat
)
