package com.surmitra.music.di

import android.content.Context
import com.surmitra.music.data.local.SurMitraDatabase
import com.surmitra.music.data.model.JamendoAudioQuality
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.remote.AudiusApi
import com.surmitra.music.data.remote.DeezerApi
import com.surmitra.music.data.remote.JamendoApi
import com.surmitra.music.data.remote.LrcLibApi
import com.surmitra.music.data.repository.DownloadRepository
import com.surmitra.music.data.repository.LyricsRepository
import com.surmitra.music.data.repository.MusicLibraryRepository
import com.surmitra.music.data.repository.OnlineCatalogRepository
import com.surmitra.music.data.repository.PlaylistRepository
import com.surmitra.music.data.repository.SettingsRepository
import com.surmitra.music.playback.EqualizerController
import com.surmitra.music.playback.PlayerController
import com.surmitra.music.util.isOnWifi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Hand-rolled composition root — deliberately not Hilt/Dagger, so there is
 * exactly one obvious file to read to see how the app is wired together.
 * Swap in Hilt later if the codebase outgrows this.
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
            .build()
    }

    private fun retrofitFor(baseUrl: String): Retrofit = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    // Three real, licensed network sources — see RemoteApis.kt for details on each.
    private val jamendoApi: JamendoApi by lazy {
        retrofitFor("https://api.jamendo.com/v3.0/").create(JamendoApi::class.java)
    }
    private val deezerApi: DeezerApi by lazy {
        retrofitFor("https://api.deezer.com/").create(DeezerApi::class.java)
    }
    private val lrcLibApi: LrcLibApi by lazy {
        retrofitFor("https://lrclib.net/").create(LrcLibApi::class.java)
    }
    private val audiusApi: AudiusApi by lazy {
        retrofitFor("https://api.audius.co/").create(AudiusApi::class.java)
    }

    private val database: SurMitraDatabase by lazy { SurMitraDatabase.getInstance(appContext) }

    val musicLibraryRepository: MusicLibraryRepository by lazy { MusicLibraryRepository(appContext) }
    val onlineCatalogRepository: OnlineCatalogRepository by lazy {
        OnlineCatalogRepository(jamendoApi, deezerApi, audiusApi, jamendoFormat = ::effectiveJamendoFormat)
    }
    val lyricsRepository: LyricsRepository by lazy { LyricsRepository(appContext, lrcLibApi) }
    val playlistRepository: PlaylistRepository by lazy { PlaylistRepository(database, musicLibraryRepository) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(appContext) }
    val downloadRepository: DownloadRepository by lazy { DownloadRepository(appContext, database, okHttpClient) }

    val equalizerController: EqualizerController by lazy { EqualizerController() }
    val playerController: PlayerController by lazy {
        PlayerController(appContext).also { it.setSongLookup(::resolveSongById) }
    }

    /**
     * In-memory registry of online songs the UI has recently fetched, so
     * playback callbacks (not suspend-friendly) can resolve a queue item's
     * title/art synchronously. Browsing ViewModels call [rememberOnlineSongs]
     * whenever they load Jamendo/Deezer results.
     */
    private val recentOnlineSongs = mutableMapOf<String, Song>()

    fun rememberOnlineSongs(songs: List<Song>) {
        songs.forEach { recentOnlineSongs[it.id] = it }
    }

    private fun resolveSongById(id: String): Song? =
        musicLibraryRepository.findById(id) ?: recentOnlineSongs[id]

    /**
     * The actual Jamendo `audioformat` to request right now: the user's chosen
     * tier, unless Data Saver is on and the device isn't on Wi-Fi, in which
     * case it's forced down to [JamendoAudioQuality.DATA_SAVER] regardless —
     * this is what makes "separate quality for Wi-Fi vs. mobile data" real.
     */
    /**
     * Starts a download unless Wi-Fi-only downloads is on and the device
     * isn't on Wi-Fi — fires and forgets, same shape as [playAndRemember].
     */
    fun requestDownload(song: Song) {
        appScope.launch {
            val wifiOnly = settingsRepository.wifiOnlyDownloads.first()
            if (wifiOnly && !appContext.isOnWifi()) {
                downloadRepository.markBlocked(song.id, "Wi-Fi only downloads is on — connect to Wi-Fi, or turn it off in Settings")
                return@launch
            }
            downloadRepository.startDownload(song)
        }
    }

    private suspend fun effectiveJamendoFormat(): String {
        val dataSaverOn = settingsRepository.dataSaverOnMobile.first()
        if (dataSaverOn && !appContext.isOnWifi()) return JamendoAudioQuality.DATA_SAVER.apiFormat
        return settingsRepository.jamendoAudioQuality.first().apiFormat
    }

    /** Small app-lifetime scope for fire-and-forget writes (history) that shouldn't block a UI click. */
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * What every screen calls to start playback, instead of touching
     * [playerController] directly: it also makes sure online tracks can be
     * resolved back to a [Song] later (lock screen, queue) and that the
     * track lands in play history — one place, so no screen can forget it.
     */
    fun playAndRemember(songs: List<Song>, startIndex: Int) {
        if (songs.isEmpty()) return
        // Play from the downloaded copy, not the network, for anything saved offline.
        val resolved = songs.map { song -> downloadRepository.localUri(song.id)?.let { song.copy(streamUri = it) } ?: song }
        rememberOnlineSongs(resolved)
        playerController.playQueue(resolved, startIndex)
        appScope.launch { playlistRepository.recordPlayed(resolved[startIndex]) }
    }
}
