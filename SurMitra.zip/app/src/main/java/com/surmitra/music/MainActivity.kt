package com.surmitra.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.surmitra.music.data.repository.AppTheme
import com.surmitra.music.ui.navigation.SurMitraNavHost
import com.surmitra.music.ui.theme.SurMitraTheme
import com.surmitra.music.util.audioPermissionName
import com.surmitra.music.util.hasAudioPermission

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        val container = (application as SurMitraApp).container
        container.playerController.connect()

        setContent {
            var audioGranted by remember { mutableStateOf(hasAudioPermission()) }

            val permissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { results ->
                audioGranted = results[audioPermissionName] ?: hasAudioPermission()
            }

            LaunchedEffect(Unit) {
                val toRequest = buildList {
                    if (!hasAudioPermission()) add(audioPermissionName)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                if (toRequest.isNotEmpty()) permissionLauncher.launch(toRequest.toTypedArray())
            }

            LaunchedEffect(audioGranted) {
                if (audioGranted) container.musicLibraryRepository.rescan()
            }

            val appTheme by container.settingsRepository.theme.collectAsStateWithLifecycle(initialValue = AppTheme.SYSTEM)

            SurMitraTheme(appTheme = appTheme) {
                SurMitraNavHost(container)
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) {
            (application as SurMitraApp).container.playerController.release()
        }
        super.onDestroy()
    }
}
