package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.surmitra.music.R
import com.surmitra.music.data.model.SourceSection
import com.surmitra.music.data.model.Song
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.EmptyState
import com.surmitra.music.ui.components.SectionHeader
import com.surmitra.music.ui.components.SongRow
import com.surmitra.music.ui.components.sourceSectionTitle
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(container: AppContainer, onOpenPlayer: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var localResults by remember { mutableStateOf<List<Song>>(emptyList()) }
    var onlineResults by remember { mutableStateOf<List<SourceSection>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }

    LaunchedEffect(query) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            localResults = emptyList(); onlineResults = emptyList(); searching = false
            return@LaunchedEffect
        }
        searching = true
        delay(400) // debounce — avoids a network call per keystroke
        localResults = container.musicLibraryRepository.search(trimmed)
        onlineResults = container.onlineCatalogRepository.search(trimmed)
        container.rememberOnlineSongs(onlineResults.flatMap { it.songs })
        searching = false
    }

    val noResults = !searching && query.isNotBlank() && localResults.isEmpty() && onlineResults.all { it.songs.isEmpty() }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(stringResource(R.string.empty_search_title)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = null)
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth()
                )
            })
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                query.isBlank() -> item { EmptyState(title = stringResource(R.string.empty_search_title)) }
                searching -> item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                }
                noResults -> item { EmptyState(title = stringResource(R.string.empty_search_results, query)) }
                else -> {
                    if (localResults.isNotEmpty()) {
                        item { SectionHeader(title = "On this device") }
                        items(localResults, key = { "local:" + it.id }) { song ->
                            SongRow(song = song, onClick = {
                                container.playAndRemember(localResults, localResults.indexOf(song))
                                onOpenPlayer()
                            })
                        }
                    }
                    onlineResults.forEach { section ->
                        if (section.songs.isNotEmpty()) {
                            item { SectionHeader(title = sourceSectionTitle(section)) }
                            items(section.songs, key = { "online:" + it.id }) { song ->
                                SongRow(song = song, onClick = {
                                    container.playAndRemember(section.songs, section.songs.indexOf(song))
                                    onOpenPlayer()
                                })
                            }
                        }
                    }
                }
            }
        }
    }
}
