package com.surmitra.music.data.repository

import com.surmitra.music.BuildConfig
import com.surmitra.music.data.model.CatalogResult
import com.surmitra.music.data.model.Genre
import com.surmitra.music.data.model.Radio
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.model.SourceSection
import com.surmitra.music.data.model.TrackSource
import com.surmitra.music.data.remote.AudiusApi
import com.surmitra.music.data.remote.AudiusTrackDto
import com.surmitra.music.data.remote.DeezerApi
import com.surmitra.music.data.remote.DeezerTrackDto
import com.surmitra.music.data.remote.JamendoApi
import com.surmitra.music.data.remote.JamendoTrackDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.IOException

class OnlineCatalogRepository(
    private val jamendoApi: JamendoApi,
    private val deezerApi: DeezerApi,
    private val audiusApi: AudiusApi,
    /** Resolved per call so a live Settings change (quality tier, data saver) applies immediately. */
    private val jamendoFormat: suspend () -> String
) {
    private val jamendoConfigured: Boolean get() = BuildConfig.JAMENDO_CLIENT_ID.isNotBlank()

    suspend fun trending(): List<SourceSection> = withContext(Dispatchers.IO) {
        coroutineScope {
            val jamendoDeferred = async { runCatching { jamendoTracks(order = "popularity_month") }.getOrDefault(emptyList()) }
            val deezerDeferred = async { runCatching { deezerApi.getChartTracks(limit = 25).data.mapNotNull { it.toSong() } }.getOrDefault(emptyList()) }
            val audiusDeferred = async { runCatching { audiusApi.trending().data.mapNotNull { it.toSong() } }.getOrDefault(emptyList()) }
            listOfNotNull(
                jamendoDeferred.await().takeIf { it.isNotEmpty() }?.let { SourceSection(TrackSource.JAMENDO, it) },
                deezerDeferred.await().takeIf { it.isNotEmpty() }?.let { SourceSection(TrackSource.DEEZER_PREVIEW, it) },
                audiusDeferred.await().takeIf { it.isNotEmpty() }?.let { SourceSection(TrackSource.AUDIUS, it) }
            )
        }
    }

    suspend fun newReleases(): CatalogResult<List<Song>> {
        if (!jamendoConfigured) return CatalogResult.NotConfigured
        return try {
            CatalogResult.Success(jamendoTracks(order = "releasedate_desc"))
        } catch (_: IOException) {
            CatalogResult.NetworkError
        }
    }

    suspend fun search(query: String): List<SourceSection> = withContext(Dispatchers.IO) {
        coroutineScope {
            val jamendoDeferred = async { runCatching { jamendoTracks(search = query) }.getOrDefault(emptyList()) }
            val deezerDeferred = async { runCatching { deezerApi.searchTracks(query).data.mapNotNull { it.toSong() } }.getOrDefault(emptyList()) }
            val audiusDeferred = async { runCatching { audiusApi.search(query).data.mapNotNull { it.toSong() } }.getOrDefault(emptyList()) }
            listOfNotNull(
                jamendoDeferred.await().takeIf { it.isNotEmpty() }?.let { SourceSection(TrackSource.JAMENDO, it) },
                deezerDeferred.await().takeIf { it.isNotEmpty() }?.let { SourceSection(TrackSource.DEEZER_PREVIEW, it) },
                audiusDeferred.await().takeIf { it.isNotEmpty() }?.let { SourceSection(TrackSource.AUDIUS, it) }
            )
        }
    }

    suspend fun tracksByTag(tag: String): List<Song> =
        runCatching { jamendoTracks(tags = tag) }.getOrDefault(emptyList())

    suspend fun radios(): List<Radio> {
        if (!jamendoConfigured) return emptyList()
        return try {
            jamendoApi.getRadios(clientId = BuildConfig.JAMENDO_CLIENT_ID).results.map {
                Radio(name = it.name, displayName = it.dispname ?: it.name, imageUrl = it.image)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun radioStreamUrl(radioName: String): String? {
        if (!jamendoConfigured) return null
        return try {
            jamendoApi.getRadioStream(clientId = BuildConfig.JAMENDO_CLIENT_ID, name = radioName)
                .results.firstOrNull()?.stream
        } catch (_: Exception) {
            null
        }
    }

    suspend fun genres(): List<Genre> = try {
        deezerApi.getGenres().data
            .filter { it.name.isNotBlank() && it.name != "All" }
            .map { Genre(name = it.name, songCount = 0) }
    } catch (_: Exception) {
        emptyList()
    }

    private suspend fun jamendoTracks(
        order: String = "popularity_month",
        search: String? = null,
        tags: String? = null
    ): List<Song> {
        if (!jamendoConfigured) return emptyList()
        return jamendoApi.getTracks(
            clientId = BuildConfig.JAMENDO_CLIENT_ID,
            order = order,
            search = search,
            tags = tags,
            audioFormat = jamendoFormat()
        ).results.mapNotNull { it.toSong() }
    }

    private fun JamendoTrackDto.toSong(): Song? {
        if (audio.isNullOrBlank()) return null
        return Song(
            id = "jamendo:$id",
            title = name,
            artist = artist_name,
            album = album_name.orEmpty().ifBlank { "Single" },
            albumArtUri = album_image,
            durationMs = duration * 1000L,
            source = TrackSource.JAMENDO,
            streamUri = audio,
            isDownloadAllowed = audiodownload_allowed == true && !audiodownload.isNullOrBlank()
        )
    }

    private fun DeezerTrackDto.toSong(): Song? {
        if (preview.isNullOrBlank()) return null
        return Song(
            id = "deezer:$id",
            title = title,
            artist = artist?.name ?: "Unknown artist",
            album = album?.title ?: "Unknown album",
            albumArtUri = album?.cover_medium,
            durationMs = duration * 1000L,
            source = TrackSource.DEEZER_PREVIEW,
            streamUri = preview,
            isDownloadAllowed = false
        )
    }

    private fun AudiusTrackDto.toSong(): Song? {
        if (duration == null || duration <= 0) return null
        return Song(
            id = "audius:$id",
            title = title,
            artist = user?.name?.takeIf { it.isNotBlank() } ?: user?.handle ?: "Unknown artist",
            album = genre?.takeIf { it.isNotBlank() } ?: "Audius",
            albumArtUri = artwork?.art480 ?: artwork?.art150,
            durationMs = duration * 1000L,
            source = TrackSource.AUDIUS,
            // Documented stream endpoint (docs.audius.co/developers/api/stream-track); follows
            // redirects to the hosting content node, which ExoPlayer handles natively.
            streamUri = "https://api.audius.co/v1/tracks/$id/stream?app_name=SurMitra",
            isDownloadAllowed = false
        )
    }
}
