package com.surmitra.music.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

// ---------------------------------------------------------------------------
// Jamendo — free, Creative-Commons-licensed catalog. Full-length streaming is
// part of its public API (https://developer.jamendo.com), no business deal
// required, only a free client_id. This is the app's real "online catalog"
// for full-track playback.
// ---------------------------------------------------------------------------

interface JamendoApi {
    @GET("tracks/")
    suspend fun getTracks(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 30,
        @Query("order") order: String = "popularity_month",
        @Query("search") search: String? = null,
        @Query("tags") tags: String? = null,
        @Query("include") include: String = "musicinfo",
        // mp31=96kbps, mp32=good-quality VBR, flac=lossless — all 4 formats are part of the
        // free public API, no extra permission needed; defaulting to mp32 alone already fixes
        // the low-bitrate mp31 this app used to request implicitly by leaving the param unset.
        @Query("audioformat") audioFormat: String = "mp32"
    ): JamendoTracksResponse

    @GET("radios/")
    suspend fun getRadios(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json"
    ): JamendoRadiosResponse

    @GET("radios/stream/")
    suspend fun getRadioStream(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("name") name: String
    ): JamendoRadioStreamResponse
}

data class JamendoTracksResponse(val results: List<JamendoTrackDto> = emptyList())
data class JamendoTrackDto(
    val id: String,
    val name: String,
    val artist_name: String,
    val album_name: String?,
    val album_image: String?,
    val duration: Int,
    val audio: String?,
    val audiodownload: String?,
    val audiodownload_allowed: Boolean?
)

data class JamendoRadiosResponse(val results: List<JamendoRadioDto> = emptyList())
data class JamendoRadioDto(val name: String, val dispname: String?, val image: String?)

data class JamendoRadioStreamResponse(val results: List<JamendoRadioStreamDto> = emptyList())
data class JamendoRadioStreamDto(val stream: String?, val dispname: String?)

// ---------------------------------------------------------------------------
// Deezer — public catalog/search/chart reads need no key at all. Legally,
// full tracks are NOT available through this API ("because of legal reasons
// we can't provide the audio file" — Deezer's own developer FAQ); only
// 30-second previews are. Used here for richer metadata, trending charts and
// genre browsing, with the preview as a fallback playable source.
// ---------------------------------------------------------------------------

interface DeezerApi {
    @GET("search/track")
    suspend fun searchTracks(@Query("q") query: String, @Query("limit") limit: Int = 25): DeezerListResponse

    @GET("chart/0/tracks")
    suspend fun getChartTracks(@Query("limit") limit: Int = 25): DeezerListResponse

    @GET("genre")
    suspend fun getGenres(): DeezerGenreListResponse
}

data class DeezerListResponse(val data: List<DeezerTrackDto> = emptyList())
data class DeezerTrackDto(
    val id: Long,
    val title: String,
    val duration: Int,
    val preview: String?,
    val artist: DeezerArtistDto?,
    val album: DeezerAlbumDto?
)
data class DeezerArtistDto(val id: Long, val name: String)
data class DeezerAlbumDto(val id: Long, val title: String, val cover_medium: String?)

data class DeezerGenreListResponse(val data: List<DeezerGenreDto> = emptyList())
data class DeezerGenreDto(val id: Long, val name: String, val picture_medium: String?)

// ---------------------------------------------------------------------------
// LRCLIB — free, open, keyless API for time-synced lyrics (lrclib.net).
// Community-sourced; used only to display lyrics alongside playback, never
// stored or redistributed beyond the current screen.
// ---------------------------------------------------------------------------

interface LrcLibApi {
    @GET("api/get")
    suspend fun getExact(
        @Query("track_name") trackName: String,
        @Query("artist_name") artistName: String,
        @Query("album_name") albumName: String? = null,
        @Query("duration") durationSeconds: Int? = null
    ): Response<LrcLibTrackDto>

    @GET("api/search")
    suspend fun search(
        @Query("track_name") trackName: String,
        @Query("artist_name") artistName: String? = null
    ): List<LrcLibTrackDto>
}

data class LrcLibTrackDto(
    val id: Long,
    val trackName: String?,
    val artistName: String?,
    val duration: Double?,
    val instrumental: Boolean?,
    val plainLyrics: String?,
    val syncedLyrics: String?
)

// ---------------------------------------------------------------------------
// Audius — a second genuine full-length, licensed catalog alongside Jamendo:
// a decentralised platform where artists upload tracks under terms that
// explicitly permit third-party streaming through this API (api.audius.co,
// docs.audius.co). Free, keyless for read/stream at this volume; a free API
// key from Audius raises the rate limit later if this app ever needs it.
// Skews independent/electronic/hip-hop rather than mainstream film or major-
// label pop, but it's a real, different full-catalog pool from Jamendo's.
// ---------------------------------------------------------------------------

interface AudiusApi {
    @GET("v1/tracks/trending")
    suspend fun trending(
        @Query("app_name") appName: String = "SurMitra",
        @Query("limit") limit: Int = 25
    ): AudiusTracksResponse

    @GET("v1/tracks/search")
    suspend fun search(
        @Query("query") query: String,
        @Query("app_name") appName: String = "SurMitra",
        @Query("limit") limit: Int = 25
    ): AudiusTracksResponse
}

data class AudiusTracksResponse(val data: List<AudiusTrackDto> = emptyList())
data class AudiusTrackDto(
    val id: String,
    val title: String,
    val user: AudiusUserDto?,
    val genre: String?,
    val duration: Int?,
    val artwork: AudiusArtworkDto?
)
data class AudiusUserDto(val name: String?, val handle: String?)
data class AudiusArtworkDto(
    @SerializedName("480x480") val art480: String? = null,
    @SerializedName("150x150") val art150: String? = null
)
