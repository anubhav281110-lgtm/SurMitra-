package com.surmitra.music.data.local

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.model.TrackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Reads the on-device audio library via MediaStore. Nothing here ever leaves
 * the device — this only talks to the local content provider.
 */
class MusicStoreScanner(private val context: Context) {

    /** Scans every row MediaStore reports as music. Returns an empty list on denied permission. */
    suspend fun scan(): List<Song> = withContext(Dispatchers.IO) {
        val genreByMediaId = try {
            buildGenreMap()
        } catch (_: Exception) {
            emptyMap()
        }
        val songs = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 15000"

        try {
            context.contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")
                ?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)

                    while (cursor.moveToNext()) {
                        val mediaId = cursor.getLong(idCol)
                        val contentUri = ContentUris.withAppendedId(collection, mediaId)
                        val mime = cursor.getString(mimeCol)
                        songs += Song(
                            id = "local:$mediaId",
                            title = cursor.getString(titleCol) ?: "Unknown title",
                            artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                            album = cursor.getString(albumCol)?.takeIf { it != "<unknown>" } ?: "Unknown album",
                            albumArtUri = cachedArtPathFor(mediaId, contentUri),
                            durationMs = cursor.getLong(durationCol),
                            source = TrackSource.LOCAL,
                            streamUri = contentUri.toString(),
                            genre = genreByMediaId[mediaId],
                            isDownloadAllowed = false,
                            localFormat = friendlyFormat(mime)
                        )
                    }
                }
        } catch (_: SecurityException) {
            // Permission not granted — caller shows the permission prompt instead.
        }
        songs
    }

    /**
     * MediaStore has no single "genre" column that's reliable across OS
     * versions, so genre lives in a separate Genres table with a Members
     * junction table per genre. This builds a one-shot mediaId -> genre map.
     */
    private fun buildGenreMap(): Map<Long, String> {
        val map = mutableMapOf<Long, String>()
        val genreProjection = arrayOf(MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME)
        context.contentResolver.query(
            MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI, genreProjection, null, null, null
        )?.use { genreCursor ->
            val idCol = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
            val nameCol = genreCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
            while (genreCursor.moveToNext()) {
                val genreId = genreCursor.getLong(idCol)
                val genreName = genreCursor.getString(nameCol) ?: continue
                val membersUri = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                context.contentResolver.query(
                    membersUri, arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID), null, null, null
                )?.use { memberCursor ->
                    val audioIdCol = memberCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID)
                    while (memberCursor.moveToNext()) {
                        map[memberCursor.getLong(audioIdCol)] = genreName
                    }
                }
            }
        }
        return map
    }

    /**
     * Extracts embedded album art once per track and caches it as a small
     * JPEG under the app's cache dir, returning a file:// Uri Coil can load
     * directly. Returns null if the track has no embedded art.
     */
    private fun cachedArtPathFor(mediaId: Long, contentUri: Uri): String? {
        val cacheDir = File(context.cacheDir, "album_art").apply { mkdirs() }
        val cached = File(cacheDir, "$mediaId.jpg")
        if (cached.exists()) return Uri.fromFile(cached).toString()

        val bitmap = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(contentUri, Size(512, 512), null)
            } else {
                MediaMetadataRetriever().use { retriever ->
                    retriever.setDataSource(context, contentUri)
                    retriever.embeddedPicture?.let { bytes ->
                        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                }
            }
        } catch (_: Exception) {
            null
        } ?: return null

        return try {
            FileOutputStream(cached).use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
            }
            Uri.fromFile(cached).toString()
        } catch (_: Exception) {
            null
        }
    }

    private fun friendlyFormat(mime: String?): String = when (mime) {
        "audio/flac", "audio/x-flac" -> "FLAC"
        "audio/x-wav", "audio/wav" -> "WAV"
        "audio/ogg" -> "OGG"
        "audio/mpeg" -> "MP3"
        "audio/mp4", "audio/m4a" -> "M4A"
        else -> mime?.substringAfter("/")?.uppercase() ?: "Audio"
    }
}

/** Closes a [MediaMetadataRetriever] after use; it doesn't implement Closeable on older API levels. */
private inline fun <T> MediaMetadataRetriever.use(block: (MediaMetadataRetriever) -> T): T {
    try {
        return block(this)
    } finally {
        release()
    }
}
