package com.surmitra.music.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.surmitra.music.data.model.JamendoAudioQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "surmitra_settings")

enum class AppTheme { SYSTEM, LIGHT, DARK }

/**
 * Settings that actually do something real. Deezer still exposes no
 * selectable bitrate — previews are fixed, full stop — but Jamendo's API
 * genuinely does (mp31/mp32/flac via `audioformat`), so [jamendoAudioQuality]
 * is a real control, not a cosmetic one: picking Lossless here changes the
 * actual query sent to Jamendo. [dataSaverOnMobile] overrides it down to the
 * smallest format while off Wi-Fi, regardless of the chosen tier.
 */
class SettingsRepository(context: Context) {
    private val store = context.applicationContext.dataStore

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val DATA_SAVER = booleanPreferencesKey("data_saver_mobile")
        val WIFI_ONLY_DOWNLOADS = booleanPreferencesKey("wifi_only_downloads")
        val JAMENDO_QUALITY = stringPreferencesKey("jamendo_quality")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_PRESET = stringPreferencesKey("eq_preset_index")
        val EQ_BANDS = stringPreferencesKey("eq_band_levels")
    }

    val theme: Flow<AppTheme> = store.data.map {
        runCatching { AppTheme.valueOf(it[Keys.THEME] ?: AppTheme.SYSTEM.name) }.getOrDefault(AppTheme.SYSTEM)
    }
    suspend fun setTheme(theme: AppTheme) = store.edit { it[Keys.THEME] = theme.name }

    /** On by default — matches "never advertise quality the source can't give" by defaulting conservative. */
    val dataSaverOnMobile: Flow<Boolean> = store.data.map { it[Keys.DATA_SAVER] ?: true }
    suspend fun setDataSaverOnMobile(enabled: Boolean) = store.edit { it[Keys.DATA_SAVER] = enabled }

    val wifiOnlyDownloads: Flow<Boolean> = store.data.map { it[Keys.WIFI_ONLY_DOWNLOADS] ?: true }
    suspend fun setWifiOnlyDownloads(enabled: Boolean) = store.edit { it[Keys.WIFI_ONLY_DOWNLOADS] = enabled }

    /** Standard (mp32, good-quality VBR) by default — Lossless is real but costs real bandwidth. */
    val jamendoAudioQuality: Flow<JamendoAudioQuality> = store.data.map {
        runCatching { JamendoAudioQuality.valueOf(it[Keys.JAMENDO_QUALITY] ?: JamendoAudioQuality.STANDARD.name) }
            .getOrDefault(JamendoAudioQuality.STANDARD)
    }
    suspend fun setJamendoAudioQuality(quality: JamendoAudioQuality) =
        store.edit { it[Keys.JAMENDO_QUALITY] = quality.name }

    val equalizerEnabled: Flow<Boolean> = store.data.map { it[Keys.EQ_ENABLED] ?: false }
    suspend fun setEqualizerEnabled(enabled: Boolean) = store.edit { it[Keys.EQ_ENABLED] = enabled }

    /** -1 means "custom" (manual band levels below); 0+ indexes the device's own preset list. */
    val equalizerPresetIndex: Flow<Int> = store.data.map { it[Keys.EQ_PRESET]?.toIntOrNull() ?: -1 }
    suspend fun setEqualizerPreset(index: Int) = store.edit { it[Keys.EQ_PRESET] = index.toString() }

    val equalizerBandLevels: Flow<List<Int>> = store.data.map { prefs ->
        prefs[Keys.EQ_BANDS]?.split(",")?.mapNotNull { it.toIntOrNull() } ?: emptyList()
    }
    suspend fun setEqualizerBandLevels(levels: List<Int>) =
        store.edit { it[Keys.EQ_BANDS] = levels.joinToString(",") }
}
