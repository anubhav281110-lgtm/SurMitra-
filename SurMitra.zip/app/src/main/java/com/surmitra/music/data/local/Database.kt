package com.surmitra.music.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Delete
import android.content.Context
import kotlinx.coroutines.flow.Flow

// ---------------------------------------------------------------------------
// Entities
// ---------------------------------------------------------------------------

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long
)

@Entity(tableName = "playlist_songs")
data class PlaylistSongEntity(
    @PrimaryKey(autoGenerate = true) val entryId: Long = 0,
    val playlistId: Long,
    val songId: String,
    val position: Int
)

@Entity(tableName = "favourites")
data class FavouriteEntity(
    @PrimaryKey val songId: String,
    val addedAt: Long
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val songId: String,
    val playedAt: Long
)

/**
 * A denormalised copy of a [com.surmitra.music.data.model.Song] so that
 * playlists, favourites and history can render instantly without re-hitting
 * MediaStore or the network, and still show something if an online track
 * later disappears from the catalog.
 */
@Entity(tableName = "cached_songs")
data class CachedSongEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtUri: String?,
    val durationMs: Long,
    val source: String,
    val streamUri: String,
    val genre: String?,
    val isDownloadAllowed: Boolean,
    val localFormat: String?
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val songId: String,
    val localFilePath: String,
    val downloadedAt: Long,
    val sizeBytes: Long
)

// ---------------------------------------------------------------------------
// DAOs
// ---------------------------------------------------------------------------

@Dao
interface PlaylistDao {
    @Insert
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, name: String)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun clearPlaylistSongs(playlistId: Long)

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :playlistId")
    fun observePlaylist(playlistId: Long): Flow<PlaylistEntity?>

    @Insert
    suspend fun addSongToPlaylist(entry: PlaylistSongEntity)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: String)

    @Query("SELECT songId FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position ASC")
    fun observeSongIdsForPlaylist(playlistId: Long): Flow<List<String>>

    @Query("SELECT COUNT(*) FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun songCountForPlaylist(playlistId: Long): Int

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun nextPosition(playlistId: Long): Int
}

@Dao
interface FavouriteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: FavouriteEntity)

    @Query("DELETE FROM favourites WHERE songId = :songId")
    suspend fun delete(songId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favourites WHERE songId = :songId)")
    fun observeIsFavourite(songId: String): Flow<Boolean>

    @Query("SELECT songId FROM favourites ORDER BY addedAt DESC")
    fun observeFavouriteIds(): Flow<List<String>>
}

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(entity: HistoryEntity)

    @Query(
        """SELECT songId FROM history GROUP BY songId ORDER BY MAX(playedAt) DESC LIMIT :limit"""
    )
    fun observeRecentSongIds(limit: Int): Flow<List<String>>

    @Query("DELETE FROM history WHERE playedAt < :olderThan")
    suspend fun trimOlderThan(olderThan: Long)
}

@Dao
interface CachedSongDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(song: CachedSongEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(songs: List<CachedSongEntity>)

    @Query("SELECT * FROM cached_songs WHERE id = :id")
    suspend fun getById(id: String): CachedSongEntity?

    @Query("SELECT * FROM cached_songs WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<String>): List<CachedSongEntity>
}

@Dao
interface DownloadDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: DownloadEntity)

    @Delete
    suspend fun delete(entity: DownloadEntity)

    @Query("SELECT * FROM downloads ORDER BY downloadedAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE songId = :songId")
    suspend fun getBySongId(songId: String): DownloadEntity?
}

// ---------------------------------------------------------------------------
// Database
// ---------------------------------------------------------------------------

@Database(
    entities = [
        PlaylistEntity::class,
        PlaylistSongEntity::class,
        FavouriteEntity::class,
        HistoryEntity::class,
        CachedSongEntity::class,
        DownloadEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SurMitraDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun favouriteDao(): FavouriteDao
    abstract fun historyDao(): HistoryDao
    abstract fun cachedSongDao(): CachedSongDao
    abstract fun downloadDao(): DownloadDao

    companion object {
        @Volatile private var instance: SurMitraDatabase? = null

        fun getInstance(context: Context): SurMitraDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SurMitraDatabase::class.java,
                    "surmitra.db"
                ).build().also { instance = it }
            }
    }
}
