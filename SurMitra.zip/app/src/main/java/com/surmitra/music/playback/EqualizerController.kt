package com.surmitra.music.playback

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqualizerState(
    val available: Boolean = false,
    val enabled: Boolean = false,
    val presetNames: List<String> = emptyList(),
    val currentPresetIndex: Int = -1, // -1 == custom band levels, not a device preset
    val minLevelMb: Short = -1500,
    val maxLevelMb: Short = 1500,
    val bandCenterFreqHz: List<Int> = emptyList(),
    val bandLevels: List<Short> = emptyList(),
    val bassBoostAvailable: Boolean = false,
    val bassBoostStrength: Short = 0
)

/**
 * Wraps the device's real android.media.audiofx effects, attached to
 * whichever ExoPlayer audio session is currently live. This is a genuine
 * system equalizer — not a cosmetic slider — so its band count, preset list
 * and value range all come from the device/DSP at runtime and will differ
 * between phones. If a device exposes none of this, [state] just reports
 * available = false rather than faking controls that wouldn't do anything.
 */
class EqualizerController {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var currentSessionId: Int = 0

    private val _state = MutableStateFlow(EqualizerState())
    val state: StateFlow<EqualizerState> = _state.asStateFlow()

    /** Call once, from the service that owns the real ExoPlayer instance. */
    fun bindTo(player: ExoPlayer) {
        attachIfNeeded(player.audioSessionId)
        player.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(eventTime: AnalyticsListener.EventTime, audioSessionId: Int) {
                attachIfNeeded(audioSessionId)
            }
        })
    }

    private fun attachIfNeeded(sessionId: Int) {
        if (sessionId == 0 || sessionId == currentSessionId) return
        releaseEffects()
        currentSessionId = sessionId
        try {
            val eq = Equalizer(0, sessionId)
            eq.enabled = _state.value.enabled
            equalizer = eq

            val bb = BassBoost(0, sessionId)
            bassBoost = bb
            val bassSupported = try { bb.strengthSupported } catch (_: Exception) { false }

            val bandCount = eq.numberOfBands.toInt()
            val bands = (0 until bandCount).map { eq.getBandLevel(it.toShort()) }
            val freqs = (0 until bandCount).map { eq.getCenterFreq(it.toShort()) / 1000 }
            val presets = (0 until eq.numberOfPresets.toInt()).map { eq.getPresetName(it.toShort()) }
            val range = eq.bandLevelRange

            _state.value = _state.value.copy(
                available = true,
                presetNames = presets,
                minLevelMb = range.getOrElse(0) { -1500 },
                maxLevelMb = range.getOrElse(1) { 1500 },
                bandCenterFreqHz = freqs,
                bandLevels = bands,
                bassBoostAvailable = bassSupported
            )
            if (_state.value.enabled) applyBassBoost()
        } catch (_: Exception) {
            _state.value = _state.value.copy(available = false)
        }
    }

    fun setEnabled(enabled: Boolean) {
        try {
            equalizer?.enabled = enabled
        } catch (_: Exception) { }
        _state.value = _state.value.copy(enabled = enabled)
        applyBassBoost()
    }

    fun usePreset(index: Int) {
        val eq = equalizer ?: return
        try {
            eq.usePreset(index.toShort())
            val bands = (0 until eq.numberOfBands.toInt()).map { eq.getBandLevel(it.toShort()) }
            _state.value = _state.value.copy(currentPresetIndex = index, bandLevels = bands)
        } catch (_: Exception) { }
    }

    fun setBandLevel(band: Int, levelMb: Short) {
        val eq = equalizer ?: return
        try {
            eq.setBandLevel(band.toShort(), levelMb)
            val updated = _state.value.bandLevels.toMutableList()
            if (band in updated.indices) updated[band] = levelMb
            _state.value = _state.value.copy(currentPresetIndex = -1, bandLevels = updated)
        } catch (_: Exception) { }
    }

    fun setBassBoostStrength(strength: Short) {
        _state.value = _state.value.copy(bassBoostStrength = strength)
        applyBassBoost()
    }

    fun resetToFlat() {
        val eq = equalizer ?: return
        try {
            for (band in 0 until eq.numberOfBands.toInt()) eq.setBandLevel(band.toShort(), 0)
            _state.value = _state.value.copy(
                currentPresetIndex = -1,
                bandLevels = List(eq.numberOfBands.toInt()) { 0 }
            )
        } catch (_: Exception) { }
        setBassBoostStrength(0)
    }

    private fun applyBassBoost() {
        val bb = bassBoost ?: return
        try {
            bb.enabled = _state.value.enabled && _state.value.bassBoostStrength > 0
            if (_state.value.bassBoostAvailable) bb.setStrength(_state.value.bassBoostStrength)
        } catch (_: Exception) { }
    }

    private fun releaseEffects() {
        try { equalizer?.release() } catch (_: Exception) { }
        try { bassBoost?.release() } catch (_: Exception) { }
        equalizer = null
        bassBoost = null
    }
}
