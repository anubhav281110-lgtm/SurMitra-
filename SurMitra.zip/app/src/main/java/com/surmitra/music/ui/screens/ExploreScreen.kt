package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.surmitra.music.R
import com.surmitra.music.data.model.CatalogResult
import com.surmitra.music.data.model.Genre
import com.surmitra.music.data.model.Radio
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.model.TrackSource
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.EmptyState
import com.surmitra.music.ui.components.SectionHeader
import com.surmitra.music.ui.components.SongRow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(container: AppContainer, onOpenPlayer: () -> Unit) {
    val scope = rememberCoroutineScope()
    var genres by remember { mutableStateOf<List<Genre>>(emptyList()) }
    var newReleases by remember { mutableStateOf<CatalogResult<List<Song>>>(CatalogResult.NetworkError) }
    var radios by remember { mutableStateOf<List<Radio>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    var selectedGenre by remember { mutableStateOf<String?>(null) }
    var genreSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var loadingGenreSongs by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        genres = container.onlineCatalogRepository.genres()
        newReleases = container.onlineCatalogRepository.newReleases()
        radios = container.onlineCatalogRepository.radios()
        (newReleases as? CatalogResult.Success)?.let { container.rememberOnlineSongs(it.data) }
        loading = false
    }

    fun selectGenre(genre: Genre) {
        selectedGenre = genre.name
        loadingGenreSongs = true
        scope.launch {
            genreSongs = container.onlineCatalogRepository.tracksByTag(genre.name)
            container.rememberOnlineSongs(genreSongs)
            loadingGenreSongs = false
        }
    }

    fun playRadio(radio: Radio) = scope.launch {
        val streamUrl = container.onlineCatalogRepository.radioStreamUrl(radio.name) ?: return@launch
        val song = Song(
            id = "radio:${radio.name}", title = radio.displayName, artist = "Jamendo Radio",
            album = "Live radio", albumArtUri = radio.imageUrl, durationMs = 0,
            source = TrackSource.JAMENDO, streamUri = streamUrl
        )
        container.playAndRemember(listOf(song), 0)
        onOpenPlayer()
    }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_explore)) }) }) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (genres.isNotEmpty()) {
                item { SectionHeader(title = "Genres") }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(genres, key = { it.name }) { genre ->
                            FilterChip(
                                selected = selectedGenre == genre.name,
                                onClick = { selectGenre(genre) },
                                label = { Text(genre.name) }
                            )
                        }
                    }
                }
                if (selectedGenre != null) {
                    if (loadingGenreSongs) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                        }
                    } else {
                        items(genreSongs, key = { "genre:" + it.id }) { song ->
                            SongRow(song = song, onClick = {
                                container.playAndRemember(genreSongs, genreSongs.indexOf(song))
                                onOpenPlayer()
                            })
                        }
                    }
                }
            }

            item { SectionHeader(title = "New releases") }
            when (val result = newReleases) {
                is CatalogResult.Success -> items(result.data, key = { "new:" + it.id }) { song ->
                    SongRow(song = song, onClick = {
                        container.playAndRemember(result.data, result.data.indexOf(song))
                        onOpenPlayer()
                    })
                }
                is CatalogResult.NotConfigured -> item {
                    EmptyState(title = stringResource(R.string.error_jamendo_not_configured))
                }
                is CatalogResult.NetworkError -> item {
                    EmptyState(title = stringResource(R.string.error_network))
                }
            }

            if (radios.isNotEmpty()) {
                item { SectionHeader(title = "Jamendo radio") }
                items(radios, key = { "radio:" + it.name }) { radio ->
                    SongRow(
                        song = Song(
                            id = "radiorow:${radio.name}", title = radio.displayName, artist = "Live stream",
                            album = "", albumArtUri = radio.imageUrl, durationMs = 0,
                            source = TrackSource.JAMENDO, streamUri = ""
                        ),
                        onClick = { playRadio(radio) }
                    )
                }
            }
        }
    }
}
