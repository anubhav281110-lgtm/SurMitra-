package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Subject
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.surmitra.music.R
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.repository.DownloadState
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.AlbumArt
import com.surmitra.music.ui.components.EmptyState
import com.surmitra.music.ui.components.SongRow
import com.surmitra.music.ui.components.SourceBadge
import com.surmitra.music.util.formatDuration
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(container: AppContainer, onBack: () -> Unit, onOpenLyrics: () -> Unit) {
    val scope = rememberCoroutineScope()
    val state by container.playerController.state.collectAsStateWithLifecycle()
    val song = state.currentSong
    var showEqualizer by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    var isFavourite by remember { mutableStateOf(false) }

    LaunchedEffect(song?.id) {
        val id = song?.id
        if (id != null) container.playlistRepository.observeIsFavourite(id).collect { isFavourite = it }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.now_playing), style = MaterialTheme.typography.labelLarge) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Collapse") }
                },
                actions = {
                    IconButton(onClick = { showEqualizer = true }) {
                        Icon(Icons.Filled.Tune, contentDescription = stringResource(R.string.settings_equalizer))
                    }
                    IconButton(onClick = onOpenLyrics) {
                        Icon(Icons.Filled.Subject, contentDescription = "Lyrics")
                    }
                }
            )
        }
    ) { padding ->
        if (song == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.empty_queue_title))
            }
            return@Scaffold
        }

        val isLive = song.durationMs <= 0L
        var draggingPosition by remember(song.id) { mutableStateOf<Float?>(null) }

        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))
            AlbumArt(song.albumArtUri, size = 260.dp, shape = RoundedCornerShape(24.dp))
            Spacer(Modifier.height(28.dp))
            Text(
                song.title,
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(
                song.artist,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SourceBadge(song.source)
                if (song.isDownloadAllowed || isLive) {
                    Spacer(Modifier.width(6.dp))
                }
            }
            Spacer(Modifier.height(20.dp))

            if (isLive) {
                Text("LIVE", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
                Spacer(Modifier.height(20.dp))
            } else {
                Slider(
                    value = draggingPosition ?: state.positionMs.toFloat(),
                    onValueChange = { draggingPosition = it },
                    onValueChangeFinished = {
                        draggingPosition?.let { container.playerController.seekTo(it.toLong()) }
                        draggingPosition = null
                    },
                    valueRange = 0f..(if (state.durationMs > 0) state.durationMs.toFloat() else 1f)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatDuration((draggingPosition ?: state.positionMs.toFloat()).toLong()), style = MaterialTheme.typography.labelSmall)
                    Text(formatDuration(state.durationMs), style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(8.dp))
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                IconButton(onClick = { container.playerController.toggleShuffle() }) {
                    Icon(
                        Icons.Filled.Shuffle,
                        contentDescription = stringResource(R.string.action_shuffle),
                        tint = if (state.shuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { container.playerController.skipToPrevious() }, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = stringResource(R.string.action_previous), modifier = Modifier.size(32.dp))
                }
                FilledIconButton(onClick = { container.playerController.togglePlayPause() }, modifier = Modifier.size(68.dp)) {
                    Icon(
                        if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = stringResource(if (state.isPlaying) R.string.action_pause else R.string.action_play),
                        modifier = Modifier.size(34.dp)
                    )
                }
                IconButton(onClick = { container.playerController.skipToNext() }, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Filled.SkipNext, contentDescription = stringResource(R.string.action_next), modifier = Modifier.size(32.dp))
                }
                IconButton(onClick = { container.playerController.cycleRepeatMode() }) {
                    Icon(
                        if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = stringResource(R.string.action_repeat),
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                IconButton(onClick = { scope.launch { container.playlistRepository.toggleFavourite(song) } }) {
                    Icon(
                        if (isFavourite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = null,
                        tint = if (isFavourite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { showAddToPlaylist = true }) {
                    Icon(Icons.Filled.PlaylistAdd, contentDescription = stringResource(R.string.action_new_playlist), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { showQueue = true }) {
                    Icon(Icons.Filled.QueueMusic, contentDescription = "Queue", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (song.isDownloadAllowed) {
                    val downloadState by container.downloadRepository.stateFlow(song.id).collectAsStateWithLifecycle(
                        initialValue = container.downloadRepository.stateOf(song.id)
                    )
                    when (val ds = downloadState) {
                        is DownloadState.Downloading -> CircularProgressIndicator(
                            progress = { ds.progress },
                            modifier = Modifier.size(24.dp).padding(4.dp),
                            strokeWidth = 2.dp
                        )
                        is DownloadState.Downloaded -> IconButton(onClick = { scope.launch { container.downloadRepository.removeDownload(song.id) } }) {
                            Icon(Icons.Filled.DownloadDone, contentDescription = "Downloaded — tap to remove", tint = MaterialTheme.colorScheme.primary)
                        }
                        is DownloadState.Failed -> IconButton(onClick = { container.requestDownload(song) }) {
                            Icon(Icons.Filled.Download, contentDescription = "Download failed — tap to retry", tint = MaterialTheme.colorScheme.error)
                        }
                        DownloadState.NotDownloaded -> IconButton(onClick = { container.requestDownload(song) }) {
                            Icon(Icons.Filled.Download, contentDescription = "Download for offline", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (state.playbackError != null) {
                Spacer(Modifier.height(12.dp))
                Text(state.playbackError ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.weight(1f))
        }

        if (showEqualizer) {
            EqualizerSheet(container = container, onDismiss = { showEqualizer = false })
        }
        if (showQueue) {
            QueueSheet(
                queue = state.queue,
                currentId = song.id,
                onDismiss = { showQueue = false },
                onSelect = { index -> container.playerController.playQueue(state.queue, index) }
            )
        }
        if (showAddToPlaylist) {
            AddToPlaylistSheet(container = container, song = song, onDismiss = { showAddToPlaylist = false })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddToPlaylistSheet(container: AppContainer, song: Song, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val playlists by container.playlistRepository.observePlaylistSummaries().collectAsStateWithLifecycle(initialValue = emptyList())
    var newName by remember { mutableStateOf("") }
    var addedTo by remember { mutableStateOf<Set<Long>>(emptySet()) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(24.dp)) {
            Text(stringResource(R.string.action_new_playlist), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            if (playlists.isEmpty()) {
                Text(
                    stringResource(R.string.empty_playlists_title),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                playlists.forEach { playlist ->
                    val added = playlist.id in addedTo
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(playlist.name, style = MaterialTheme.typography.bodyLarge)
                        TextButton(
                            enabled = !added,
                            onClick = {
                                scope.launch { container.playlistRepository.addSongToPlaylist(playlist.id, song) }
                                addedTo = addedTo + playlist.id
                            }
                        ) { Text(if (added) "Added" else "Add") }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = { Text("New playlist name") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                TextButton(
                    enabled = newName.isNotBlank(),
                    onClick = {
                        val name = newName.trim()
                        scope.launch {
                            val id = container.playlistRepository.createPlaylist(name)
                            container.playlistRepository.addSongToPlaylist(id, song)
                        }
                        newName = ""
                    }
                ) { Text("Create") }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EqualizerSheet(container: AppContainer, onDismiss: () -> Unit) {
    val eqState by container.equalizerController.state.collectAsStateWithLifecycle()
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(24.dp)) {
            Text(stringResource(R.string.settings_equalizer), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(16.dp))
            if (!eqState.available) {
                Text(
                    "This device doesn't expose a system equaliser for the current audio session.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable equaliser", style = MaterialTheme.typography.bodyLarge)
                    Switch(checked = eqState.enabled, onCheckedChange = { container.equalizerController.setEnabled(it) })
                }
                if (eqState.presetNames.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(eqState.presetNames.size) { i ->
                            FilterChip(
                                selected = eqState.currentPresetIndex == i,
                                onClick = { container.equalizerController.usePreset(i) },
                                label = { Text(eqState.presetNames[i]) },
                                enabled = eqState.enabled
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                eqState.bandLevels.forEachIndexed { index, level ->
                    val label = eqState.bandCenterFreqHz.getOrNull(index)?.let { "$it Hz" } ?: "Band ${index + 1}"
                    Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Slider(
                        value = level.toFloat(),
                        onValueChange = { container.equalizerController.setBandLevel(index, it.toInt().toShort()) },
                        valueRange = eqState.minLevelMb.toFloat()..eqState.maxLevelMb.toFloat(),
                        enabled = eqState.enabled
                    )
                }
                if (eqState.bassBoostAvailable) {
                    Text("Bass boost", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Slider(
                        value = eqState.bassBoostStrength.toFloat(),
                        onValueChange = { container.equalizerController.setBassBoostStrength(it.toInt().toShort()) },
                        valueRange = 0f..1000f,
                        enabled = eqState.enabled
                    )
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { container.equalizerController.resetToFlat() }) { Text("Reset to flat") }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QueueSheet(queue: List<Song>, currentId: String?, onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        if (queue.isEmpty()) {
            EmptyState(title = stringResource(R.string.empty_queue_title), modifier = Modifier.padding(24.dp))
        } else {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 480.dp)) {
                itemsIndexed(queue, key = { _, s -> s.id }) { index, song ->
                    SongRow(
                        song = song,
                        onClick = { onSelect(index); onDismiss() },
                        trailingContent = {
                            if (song.id == currentId) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
