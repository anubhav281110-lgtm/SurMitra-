package com.surmitra.music.data.repository

import android.content.Context
import android.provider.MediaStore
import com.surmitra.music.data.model.LyricLine
import com.surmitra.music.data.model.LyricsResult
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.model.TrackSource
import com.surmitra.music.data.remote.LrcLibApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class LyricsRepository(
    private val context: Context,
    private val lrcLibApi: LrcLibApi
) {
    suspend fun lyricsFor(song: Song): LyricsResult = withContext(Dispatchers.IO) {
        if (song.source == TrackSource.LOCAL) {
            findSiblingLrc(song)?.let { return@withContext it }
        }
        fetchFromLrcLib(song)
    }

    /**
     * Best-effort: looks for a "<track>.lrc" file next to the audio file,
     * using MediaStore's legacy DATA column to resolve a path. This column
     * is deprecated but most devices still populate it for files they own.
     * Any failure here just falls through to LRCLIB.
     */
    private fun findSiblingLrc(song: Song): LyricsResult? {
        val mediaId = song.id.removePrefix("local:").toLongOrNull() ?: return null
        @Suppress("DEPRECATION")
        val path = try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media.DATA),
                "${MediaStore.Audio.Media._ID} = ?",
                arrayOf(mediaId.toString()),
                null
            )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
        } catch (_: Exception) {
            null
        } ?: return null

        val audioFile = File(path)
        val lrcFile = File(audioFile.parentFile, audioFile.nameWithoutExtension + ".lrc")
        if (!lrcFile.exists()) return null
        return try {
            parseLrc(lrcFile.readText())
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun fetchFromLrcLib(song: Song): LyricsResult = try {
        val response = lrcLibApi.getExact(
            trackName = song.title,
            artistName = song.artist,
            albumName = song.album.takeIf { it != "Unknown album" && it != "Single" },
            durationSeconds = (song.durationMs / 1000).toInt().takeIf { it > 0 }
        )
        val dto = if (response.isSuccessful) response.body() else null
        when {
            dto?.syncedLyrics?.isNotBlank() == true -> parseLrc(dto.syncedLyrics)
            dto?.plainLyrics?.isNotBlank() == true -> LyricsResult.PlainOnly(dto.plainLyrics)
            else -> searchFallback(song)
        }
    } catch (_: Exception) {
        LyricsResult.NotFound
    }

    private suspend fun searchFallback(song: Song): LyricsResult = try {
        val results = lrcLibApi.search(trackName = song.title, artistName = song.artist)
        val best = results.firstOrNull { !it.syncedLyrics.isNullOrBlank() } ?: results.firstOrNull()
        when {
            best?.syncedLyrics?.isNotBlank() == true -> parseLrc(best.syncedLyrics)
            best?.plainLyrics?.isNotBlank() == true -> LyricsResult.PlainOnly(best.plainLyrics)
            else -> LyricsResult.NotFound
        }
    } catch (_: Exception) {
        LyricsResult.NotFound
    }

    private fun parseLrc(raw: String): LyricsResult {
        val timeTag = Regex("""\[(\d{2}):(\d{2})(?:\.(\d{1,3}))?]""")
        val lines = raw.lineSequence()
            .flatMap { line ->
                val matches = timeTag.findAll(line).toList()
                if (matches.isEmpty()) return@flatMap emptySequence()
                val text = line.substring(matches.last().range.last + 1).trim()
                matches.map { m ->
                    val minutes = m.groupValues[1].toLong()
                    val seconds = m.groupValues[2].toLong()
                    val fraction = m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
                    LyricLine(timeMs = minutes * 60_000 + seconds * 1000 + fraction, text = text)
                }.asSequence()
            }
            .sortedBy { it.timeMs }
            .toList()
        return if (lines.isEmpty()) LyricsResult.NotFound else LyricsResult.Synced(lines)
    }
}
