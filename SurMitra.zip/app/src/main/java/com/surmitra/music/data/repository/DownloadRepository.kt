package com.surmitra.music.data.repository

import android.content.Context
import com.surmitra.music.data.local.CachedSongEntity
import com.surmitra.music.data.local.DownloadEntity
import com.surmitra.music.data.local.SurMitraDatabase
import com.surmitra.music.data.model.Song
import com.surmitra.music.data.model.TrackSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

sealed interface DownloadState {
    data object NotDownloaded : DownloadState
    data class Downloading(val progress: Float) : DownloadState
    data class Downloaded(val sizeBytes: Long) : DownloadState
    data class Failed(val message: String) : DownloadState
}

/**
 * Real offline downloads — not a stub. Only ever offered for tracks where
 * [Song.isDownloadAllowed] is true, which today means Jamendo tracks whose
 * API response itself reports `audiodownload_allowed`: this fetches exactly
 * that sanctioned `audiodownload` URL, nothing scraped or worked around.
 * Deezer previews and Audius streams are never downloadable here, by design.
 * Files live in app-private external storage (no extra permission, cleaned
 * up automatically on uninstall).
 */
class DownloadRepository(
    context: Context,
    private val database: SurMitraDatabase,
    private val okHttpClient: OkHttpClient
) {
    private val appContext = context.applicationContext
    private val downloadDao = database.downloadDao()
    private val cachedSongDao = database.cachedSongDao()
    private val downloadDir: File by lazy {
        File(appContext.getExternalFilesDir(null) ?: appContext.filesDir, "downloads").apply { mkdirs() }
    }

    private val _states = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val states: StateFlow<Map<String, DownloadState>> = _states.asStateFlow()
    private val localPaths = mutableMapOf<String, String>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        scope.launch {
            val rows = downloadDao.observeAll().first()
            val valid = rows.filter { File(it.localFilePath).exists() }
            valid.forEach { localPaths[it.songId] = it.localFilePath }
            _states.value = valid.associate { it.songId to DownloadState.Downloaded(it.sizeBytes) }
        }
    }

    /** `file://` URI for a completed download, for substitution ahead of the remote stream URL. */
    fun localUri(songId: String): String? = localPaths[songId]?.let { "file://$it" }

    fun stateOf(songId: String): DownloadState = _states.value[songId] ?: DownloadState.NotDownloaded
    fun stateFlow(songId: String): Flow<DownloadState> = states.map { it[songId] ?: DownloadState.NotDownloaded }

    /** Lets a caller (e.g. a blocked Wi-Fi-only check) surface a reason without a real download attempt. */
    fun markBlocked(songId: String, reason: String) {
        _states.update { it + (songId to DownloadState.Failed(reason)) }
    }

    fun startDownload(song: Song) {
        if (!song.isDownloadAllowed || song.streamUri.isBlank()) return
        if (stateOf(song.id) is DownloadState.Downloading) return
        scope.launch {
            _states.update { it + (song.id to DownloadState.Downloading(0f)) }
            val extension = song.streamUri.substringAfterLast('.', "mp3").substringBefore('?').take(4).ifBlank { "mp3" }
            val target = File(downloadDir, "${song.id.replace(':', '_').replace('/', '_')}.$extension")
            try {
                val request = Request.Builder().url(song.streamUri).build()
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
                    val body = response.body ?: throw IOException("Empty response body")
                    val total = body.contentLength()
                    body.byteStream().use { input ->
                        FileOutputStream(target).use { output ->
                            val buffer = ByteArray(16 * 1024)
                            var copied = 0L
                            while (true) {
                                val read = input.read(buffer)
                                if (read == -1) break
                                output.write(buffer, 0, read)
                                copied += read
                                if (total > 0) {
                                    val progress = (copied.toFloat() / total).coerceIn(0f, 1f)
                                    _states.update { it + (song.id to DownloadState.Downloading(progress)) }
                                }
                            }
                        }
                    }
                }
                cachedSongDao.upsert(song.toCachedEntity())
                downloadDao.insert(
                    DownloadEntity(
                        songId = song.id,
                        localFilePath = target.absolutePath,
                        downloadedAt = System.currentTimeMillis(),
                        sizeBytes = target.length()
                    )
                )
                localPaths[song.id] = target.absolutePath
                _states.update { it + (song.id to DownloadState.Downloaded(target.length())) }
            } catch (e: Exception) {
                target.delete()
                _states.update { it + (song.id to DownloadState.Failed(e.message ?: "Download failed")) }
            }
        }
    }

    suspend fun removeDownload(songId: String) = withContext(Dispatchers.IO) {
        downloadDao.getBySongId(songId)?.let { entity ->
            File(entity.localFilePath).delete()
            downloadDao.delete(entity)
        }
        localPaths.remove(songId)
        _states.update { it - songId }
    }

    suspend fun removeAllDownloads() = withContext(Dispatchers.IO) {
        downloadDao.observeAll().first().forEach { entity ->
            File(entity.localFilePath).delete()
            downloadDao.delete(entity)
        }
        localPaths.clear()
        _states.value = emptyMap()
    }

    suspend fun totalBytesUsed(): Long = withContext(Dispatchers.IO) {
        downloadDao.observeAll().first().sumOf { it.sizeBytes }
    }

    suspend fun downloadedSongs(): List<Song> = withContext(Dispatchers.IO) {
        val entities = downloadDao.observeAll().first()
        val cached = cachedSongDao.getByIds(entities.map { it.songId }).associateBy { it.id }
        entities.mapNotNull { d -> cached[d.songId]?.toSong()?.copy(streamUri = "file://${d.localFilePath}") }
    }
}

private fun Song.toCachedEntity() = CachedSongEntity(
    id = id, title = title, artist = artist, album = album, albumArtUri = albumArtUri,
    durationMs = durationMs, source = source.name, streamUri = streamUri, genre = genre,
    isDownloadAllowed = isDownloadAllowed, localFormat = localFormat
)

private fun CachedSongEntity.toSong() = Song(
    id = id, title = title, artist = artist, album = album, albumArtUri = albumArtUri,
    durationMs = durationMs, source = TrackSource.valueOf(source), streamUri = streamUri,
    genre = genre, isDownloadAllowed = isDownloadAllowed, localFormat = localFormat
)
