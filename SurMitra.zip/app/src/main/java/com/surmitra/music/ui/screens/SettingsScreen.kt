package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.surmitra.music.R
import com.surmitra.music.data.model.JamendoAudioQuality
import com.surmitra.music.data.repository.AppTheme
import com.surmitra.music.di.AppContainer
import com.surmitra.music.util.formatBytes
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(container: AppContainer, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val theme by container.settingsRepository.theme.collectAsStateWithLifecycle(initialValue = AppTheme.SYSTEM)
    val dataSaver by container.settingsRepository.dataSaverOnMobile.collectAsStateWithLifecycle(initialValue = true)
    val wifiOnlyDownloads by container.settingsRepository.wifiOnlyDownloads.collectAsStateWithLifecycle(initialValue = true)
    val jamendoQuality by container.settingsRepository.jamendoAudioQuality
        .collectAsStateWithLifecycle(initialValue = JamendoAudioQuality.STANDARD)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppTheme.entries.forEach { option ->
                    FilterChip(
                        selected = theme == option,
                        onClick = { scope.launch { container.settingsRepository.setTheme(option) } },
                        label = { Text(option.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
            Text("Jamendo streaming quality", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "A real control — Jamendo's API genuinely serves each of these formats. " +
                    "Deezer previews have no quality option to choose.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JamendoAudioQuality.entries.forEach { option ->
                    FilterChip(
                        selected = jamendoQuality == option,
                        onClick = { scope.launch { container.settingsRepository.setJamendoAudioQuality(option) } },
                        label = { Text(option.label) }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
            SettingSwitchRow(
                title = stringResource(R.string.settings_data_saver),
                body = stringResource(R.string.settings_data_saver_body),
                checked = dataSaver,
                onCheckedChange = { scope.launch { container.settingsRepository.setDataSaverOnMobile(it) } }
            )

            Spacer(Modifier.height(20.dp))
            SettingSwitchRow(
                title = stringResource(R.string.settings_wifi_only_downloads),
                checked = wifiOnlyDownloads,
                onCheckedChange = { scope.launch { container.settingsRepository.setWifiOnlyDownloads(it) } }
            )

            Spacer(Modifier.height(28.dp))
            HorizontalDivider()
            Spacer(Modifier.height(20.dp))
            DownloadsSection(container)

            Spacer(Modifier.height(28.dp))
            HorizontalDivider()
            Spacer(Modifier.height(20.dp))
            Text(stringResource(R.string.settings_about), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Full-length tracks stream from two licensed catalogs: Jamendo (Creative Commons, your " +
                    "own free client ID, quality selectable above) and Audius (a decentralised platform " +
                    "whose artists permit API streaming, free and keyless). Deezer supplies charts, search " +
                    "and genre metadata for a much larger catalog, with 30-second previews where full " +
                    "playback isn't licensed for third-party apps. Synced lyrics come from LRCLIB, a free " +
                    "community source. SurMitra never scrapes a service or bypasses DRM — and mainstream " +
                    "commercial catalogs (JioSaavn, Gaana, Wynk, Spotify's or Apple Music's full libraries) " +
                    "simply have no such API to use honestly, at any price an indie app can reach.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SettingSwitchRow(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit, body: String? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (body != null) {
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DownloadsSection(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val liveStates by container.downloadRepository.states.collectAsStateWithLifecycle()
    var downloadedCount by remember { mutableStateOf(0) }
    var totalBytes by remember { mutableStateOf(0L) }

    LaunchedEffect(liveStates) {
        downloadedCount = liveStates.values.count { it is com.surmitra.music.data.repository.DownloadState.Downloaded }
        totalBytes = container.downloadRepository.totalBytesUsed()
    }

    Text(stringResource(R.string.settings_storage), style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(4.dp))
    Text(
        if (downloadedCount == 0) {
            "No downloads yet — look for the download icon on the player for a Jamendo track."
        } else {
            "$downloadedCount track${if (downloadedCount == 1) "" else "s"} downloaded · ${formatBytes(totalBytes)}"
        },
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (downloadedCount > 0) {
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { scope.launch { container.downloadRepository.removeAllDownloads() } }) {
            Text("Remove all downloads")
        }
    }
}
