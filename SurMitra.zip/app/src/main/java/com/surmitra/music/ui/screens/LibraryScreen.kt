package com.surmitra.music.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.surmitra.music.R
import com.surmitra.music.data.model.Album
import com.surmitra.music.data.model.Artist
import com.surmitra.music.data.model.Genre
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.AlbumArt
import com.surmitra.music.ui.components.EmptyState
import com.surmitra.music.ui.components.SongRow
import kotlinx.coroutines.launch

private sealed interface Drill {
    data class ByAlbum(val id: String, val title: String) : Drill
    data class ByArtist(val id: String, val name: String) : Drill
    data class ByGenre(val name: String) : Drill
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(container: AppContainer, onOpenPlayer: () -> Unit, onOpenPlaylist: (Long) -> Unit) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var drill by remember { mutableStateOf<Drill?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    val librarySongs by container.musicLibraryRepository.songs.collectAsStateWithLifecycle()
    val isScanning by container.musicLibraryRepository.isScanning.collectAsStateWithLifecycle()
    val playlists by container.playlistRepository.observePlaylistSummaries().collectAsStateWithLifecycle(initialValue = emptyList())

    val albums = remember(librarySongs) { container.musicLibraryRepository.albums() }
    val artists = remember(librarySongs) { container.musicLibraryRepository.artists() }
    val genres = remember(librarySongs) { container.musicLibraryRepository.genres() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (drill != null) drillTitle(drill!!) else stringResource(R.string.nav_library)) },
                navigationIcon = {
                    if (drill != null) {
                        IconButton(onClick = { drill = null }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    }
                },
                actions = {
                    if (drill == null) {
                        IconButton(onClick = { scope.launch { container.musicLibraryRepository.rescan() } }) {
                            Icon(Icons.Filled.Refresh, contentDescription = stringResource(R.string.action_rescan))
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (drill == null && tab == 0) {
                FloatingActionButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.action_new_playlist))
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (isScanning) LinearProgressIndicator(Modifier.fillMaxWidth())

            val activeDrill = drill
            if (activeDrill != null) {
                val songs = when (activeDrill) {
                    is Drill.ByAlbum -> container.musicLibraryRepository.songsForAlbum(activeDrill.id)
                    is Drill.ByArtist -> container.musicLibraryRepository.songsForArtist(activeDrill.id)
                    is Drill.ByGenre -> container.musicLibraryRepository.songsForGenre(activeDrill.name)
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(songs, key = { it.id }) { song ->
                        SongRow(song = song, onClick = {
                            container.playAndRemember(songs, songs.indexOf(song))
                            onOpenPlayer()
                        })
                    }
                }
                return@Column
            }

            TabRow(selectedTabIndex = tab) {
                listOf("Playlists", "Artists", "Albums", "Genres").forEachIndexed { index, label ->
                    Tab(selected = tab == index, onClick = { tab = index }, text = { Text(label) })
                }
            }

            when (tab) {
                0 -> if (playlists.isEmpty()) {
                    EmptyState(title = stringResource(R.string.empty_playlists_title))
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(playlists, key = { it.id }) { summary ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onOpenPlaylist(summary.id) }.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(summary.name, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${summary.songCount} songs",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(Icons.Filled.ArrowForwardIos, contentDescription = null, modifier = Modifier.width(16.dp))
                            }
                        }
                    }
                }
                1 -> if (artists.isEmpty()) EmptyState(title = stringResource(R.string.empty_library_title), body = stringResource(R.string.empty_library_body))
                else LazyColumn(Modifier.fillMaxSize()) {
                    items(artists, key = { it.id }) { artist -> ArtistRow(artist) { drill = Drill.ByArtist(artist.id, artist.name) } }
                }
                2 -> if (albums.isEmpty()) EmptyState(title = stringResource(R.string.empty_library_title), body = stringResource(R.string.empty_library_body))
                else LazyColumn(Modifier.fillMaxSize()) {
                    items(albums, key = { it.id }) { album -> AlbumRow(album) { drill = Drill.ByAlbum(album.id, album.title) } }
                }
                3 -> if (genres.isEmpty()) EmptyState(title = stringResource(R.string.empty_library_title), body = stringResource(R.string.empty_library_body))
                else LazyColumn(Modifier.fillMaxSize()) {
                    items(genres, key = { it.name }) { genre -> GenreRow(genre) { drill = Drill.ByGenre(genre.name) } }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false; newPlaylistName = "" },
            title = { Text(stringResource(R.string.action_new_playlist)) },
            text = {
                OutlinedTextField(value = newPlaylistName, onValueChange = { newPlaylistName = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(
                    enabled = newPlaylistName.isNotBlank(),
                    onClick = {
                        val name = newPlaylistName.trim()
                        scope.launch { container.playlistRepository.createPlaylist(name) }
                        showCreateDialog = false
                        newPlaylistName = ""
                    }
                ) { Text(stringResource(R.string.action_new_playlist)) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false; newPlaylistName = "" }) { Text("Cancel") }
            }
        )
    }
}

private fun drillTitle(drill: Drill): String = when (drill) {
    is Drill.ByAlbum -> drill.title
    is Drill.ByArtist -> drill.name
    is Drill.ByGenre -> drill.name
}

@Composable
private fun ArtistRow(artist: Artist, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(artist.name, style = MaterialTheme.typography.titleSmall)
            Text("${artist.songCount} songs", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AlbumRow(album: Album, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumArt(album.artUri)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(album.title, style = MaterialTheme.typography.titleSmall)
            Text(
                "${album.artist} · ${album.songCount} songs",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun GenreRow(genre: Genre, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(genre.name, style = MaterialTheme.typography.titleSmall)
            Text("${genre.songCount} songs", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
