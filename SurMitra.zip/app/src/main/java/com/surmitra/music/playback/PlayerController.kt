package com.surmitra.music.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.surmitra.music.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlaybackUiState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<Song> = emptyList(),
    val isBuffering: Boolean = false,
    val playbackError: String? = null,
    val connected: Boolean = false
)

/**
 * The only thing the UI talks to for playback. It never touches ExoPlayer
 * directly — it binds a [MediaController] to [PlaybackService]'s session,
 * the same way any Media3 client app does, and mirrors its state as a flow.
 */
class PlayerController(private val context: Context) {
    private var controller: MediaController? = null
    private var songLookup: (String) -> Song? = { null }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var tickerJob: Job? = null

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    /** Lets the controller turn a bare MediaItem id back into a full [Song] (art, source badge, etc). */
    fun setSongLookup(lookup: (String) -> Song?) {
        songLookup = lookup
    }

    fun connect() {
        if (controller != null) return
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        future.addListener(
            {
                controller = future.get().also(::attachListener)
            },
            MoreExecutors.directExecutor()
        )
    }

    private fun attachListener(mc: MediaController) {
        mc.addListener(object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                publishState(player)
            }
        })
        publishState(mc)
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive) {
                controller?.let { publishState(it) }
                delay(500)
            }
        }
    }

    private fun publishState(player: Player) {
        val resolvedSong = player.currentMediaItem?.mediaId?.let(songLookup)
        val queueSongs = (0 until player.mediaItemCount).mapNotNull { index ->
            player.getMediaItemAt(index).mediaId.let(songLookup)
        }
        _state.value = _state.value.copy(
            currentSong = resolvedSong,
            isPlaying = player.isPlaying,
            positionMs = player.currentPosition.coerceAtLeast(0),
            durationMs = player.duration.takeIf { it > 0 } ?: 0L,
            shuffleEnabled = player.shuffleModeEnabled,
            repeatMode = player.repeatMode,
            queue = queueSongs,
            isBuffering = player.playbackState == Player.STATE_BUFFERING,
            playbackError = player.playerError?.message,
            connected = true
        )
    }

    fun playQueue(songs: List<Song>, startIndex: Int) {
        val mc = controller ?: return
        mc.setMediaItems(songs.map { it.toMediaItem() }, startIndex, 0L)
        mc.prepare()
        mc.play()
    }

    fun playNow(song: Song) = playQueue(listOf(song), 0)

    fun addToQueue(song: Song) {
        controller?.addMediaItem(song.toMediaItem())
    }

    fun togglePlayPause() {
        val mc = controller ?: return
        if (mc.isPlaying) mc.pause() else mc.play()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    fun skipToNext() {
        controller?.seekToNextMediaItem()
    }

    fun skipToPrevious() {
        controller?.seekToPreviousMediaItem()
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeatMode() {
        val mc = controller ?: return
        mc.repeatMode = when (mc.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun release() {
        tickerJob?.cancel()
        controller?.release()
        controller = null
    }
}

private fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id)
    .setUri(streamUri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(albumArtUri?.let { Uri.parse(it) })
            .build()
    )
    .build()
