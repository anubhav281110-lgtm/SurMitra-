package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.EmptyState
import com.surmitra.music.ui.components.SongRow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistDetailScreen(container: AppContainer, playlistId: Long, onBack: () -> Unit, onOpenPlayer: () -> Unit) {
    val scope = rememberCoroutineScope()
    val songs by container.playlistRepository.observeSongsForPlaylist(playlistId)
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val summaries by container.playlistRepository.observePlaylistSummaries()
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val playlistName = summaries.firstOrNull { it.id == playlistId }?.name ?: "Playlist"

    var showRenameDialog by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(playlistName, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) } },
                actions = {
                    IconButton(onClick = { renameText = playlistName; showRenameDialog = true }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Rename playlist")
                    }
                    IconButton(onClick = { scope.launch { container.playlistRepository.deletePlaylist(playlistId) }; onBack() }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete playlist")
                    }
                }
            )
        }
    ) { padding ->
        if (songs.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding)) {
                EmptyState(
                    title = "No songs in this playlist yet",
                    body = "Open a song anywhere in the app and use the playlist icon on the player to add it here.",
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding)) {
                items(songs, key = { it.id }) { song ->
                    SongRow(
                        song = song,
                        onClick = {
                            container.playAndRemember(songs, songs.indexOf(song))
                            onOpenPlayer()
                        },
                        trailingContent = {
                            IconButton(onClick = { scope.launch { container.playlistRepository.removeSongFromPlaylist(playlistId, song.id) } }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove from playlist")
                            }
                        }
                    )
                }
            }
        }
    }

    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename playlist") },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(
                    enabled = renameText.isNotBlank(),
                    onClick = {
                        scope.launch { container.playlistRepository.renamePlaylist(playlistId, renameText.trim()) }
                        showRenameDialog = false
                    }
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showRenameDialog = false }) { Text("Cancel") } }
        )
    }
}
