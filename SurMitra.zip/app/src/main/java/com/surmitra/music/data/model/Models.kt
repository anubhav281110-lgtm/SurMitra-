package com.surmitra.music.data.model

/**
 * Where a [Song] actually comes from. This drives what the player is allowed
 * to do with it (e.g. only [JAMENDO] tracks can ever be offered for offline
 * download, and only when the catalog itself marked them downloadable).
 */
enum class TrackSource { LOCAL, JAMENDO, DEEZER_PREVIEW, AUDIUS }

/** Jamendo's selectable stream quality. Deezer exposes no such choice — previews are fixed. */
enum class JamendoAudioQuality(val apiFormat: String, val label: String) {
    DATA_SAVER("mp31", "Data saver"),
    STANDARD("mp32", "Standard"),
    LOSSLESS("flac", "Lossless")
}

/**
 * A single playable item, regardless of where it came from. [id] is globally
 * unique and source-prefixed ("local:123", "jamendo:456", "deezer:789") so
 * the same id space can be used for favourites, playlists and history.
 */
data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtUri: String?,
    val durationMs: Long,
    val source: TrackSource,
    val streamUri: String,
    val genre: String? = null,
    val isDownloadAllowed: Boolean = false,
    /** Local-only: the file's actual codec, e.g. "FLAC", "MP3". Null for online sources. */
    val localFormat: String? = null
)

data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val artUri: String?,
    val songCount: Int
)

data class Artist(
    val id: String,
    val name: String,
    val songCount: Int
)

data class Genre(
    val name: String,
    val songCount: Int
)

data class PlaylistSummary(
    val id: Long,
    val name: String,
    val songCount: Int,
    val createdAt: Long
)

data class LyricLine(
    val timeMs: Long,
    val text: String
)

/** Result of a lyrics lookup, distinguishing "still looking" from "looked and found nothing". */
sealed interface LyricsResult {
    data object Loading : LyricsResult
    data object NotFound : LyricsResult
    data class Synced(val lines: List<LyricLine>) : LyricsResult
    data class PlainOnly(val text: String) : LyricsResult
}

/** A labelled group of search/browse results, so the UI can show where each result came from. */
data class SourceSection(
    val source: TrackSource,
    val songs: List<Song>
)

/** A Jamendo curated radio station — a live stream, not a fixed track list. */
data class Radio(
    val name: String,
    val displayName: String,
    val imageUrl: String?
)

/** Outcome of a call to an online catalog, distinguishing "empty" from "couldn't ask". */
sealed interface CatalogResult<out T> {
    data class Success<T>(val data: T) : CatalogResult<T>
    data object NetworkError : CatalogResult<Nothing>
    /** The Jamendo client_id hasn't been set in gradle.properties yet. */
    data object NotConfigured : CatalogResult<Nothing>
}

