package com.surmitra.music.ui.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.surmitra.music.R
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.MiniPlayerBar
import com.surmitra.music.ui.screens.ExploreScreen
import com.surmitra.music.ui.screens.FavouritesScreen
import com.surmitra.music.ui.screens.HomeScreen
import com.surmitra.music.ui.screens.LibraryScreen
import com.surmitra.music.ui.screens.LyricsScreen
import com.surmitra.music.ui.screens.PlayerScreen
import com.surmitra.music.ui.screens.PlaylistDetailScreen
import com.surmitra.music.ui.screens.SearchScreen
import com.surmitra.music.ui.screens.SettingsScreen

sealed class Dest(val route: String) {
    data object Home : Dest("home")
    data object Explore : Dest("explore")
    data object Search : Dest("search")
    data object Library : Dest("library")
    data object Favourites : Dest("favourites")
    data object Player : Dest("player")
    data object Lyrics : Dest("lyrics")
    data object Settings : Dest("settings")
    data object PlaylistDetail : Dest("playlist/{playlistId}") {
        const val ARG = "playlistId"
        fun routeFor(id: Long) = "playlist/$id"
    }
}

private data class BottomItem(val dest: Dest, val icon: ImageVector, val labelRes: Int)

private val bottomItems = listOf(
    BottomItem(Dest.Home, Icons.Filled.Home, R.string.nav_home),
    BottomItem(Dest.Explore, Icons.Filled.Explore, R.string.nav_explore),
    BottomItem(Dest.Search, Icons.Filled.Search, R.string.nav_search),
    BottomItem(Dest.Library, Icons.Filled.LibraryMusic, R.string.nav_library),
    BottomItem(Dest.Favourites, Icons.Filled.Favorite, R.string.nav_favourites)
)

@Composable
fun SurMitraNavHost(container: AppContainer, modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val playbackState by container.playerController.state.collectAsStateWithLifecycle()
    val isTopLevelRoute = bottomItems.any { it.dest.route == currentRoute }

    fun openPlayer() = navController.navigate(Dest.Player.route)
    fun openPlaylist(id: Long) = navController.navigate(Dest.PlaylistDetail.routeFor(id))
    fun openSettings() = navController.navigate(Dest.Settings.route)
    fun back() = navController.popBackStack()

    Scaffold(
        modifier = modifier,
        bottomBar = {
            Column {
                if (playbackState.currentSong != null && currentRoute != Dest.Player.route) {
                    MiniPlayerBar(
                        state = playbackState,
                        onTap = ::openPlayer,
                        onPlayPause = container.playerController::togglePlayPause,
                        onNext = container.playerController::skipToNext
                    )
                }
                if (isTopLevelRoute) {
                    NavigationBar {
                        bottomItems.forEach { item ->
                            NavigationBarItem(
                                selected = currentRoute == item.dest.route,
                                onClick = {
                                    navController.navigate(item.dest.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(item.icon, contentDescription = stringResource(item.labelRes)) },
                                label = { Text(stringResource(item.labelRes)) }
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Dest.Home.route) {
                HomeScreen(container, onOpenPlayer = ::openPlayer, onOpenPlaylist = ::openPlaylist, onOpenSettings = ::openSettings)
            }
            composable(Dest.Explore.route) {
                ExploreScreen(container, onOpenPlayer = ::openPlayer)
            }
            composable(Dest.Search.route) {
                SearchScreen(container, onOpenPlayer = ::openPlayer)
            }
            composable(Dest.Library.route) {
                LibraryScreen(container, onOpenPlayer = ::openPlayer, onOpenPlaylist = ::openPlaylist)
            }
            composable(Dest.Favourites.route) {
                FavouritesScreen(container, onOpenPlayer = ::openPlayer)
            }
            composable(Dest.Player.route) {
                PlayerScreen(container, onBack = ::back, onOpenLyrics = { navController.navigate(Dest.Lyrics.route) })
            }
            composable(Dest.Lyrics.route) {
                LyricsScreen(container, onBack = ::back)
            }
            composable(Dest.Settings.route) {
                SettingsScreen(container, onBack = ::back)
            }
            composable(
                route = Dest.PlaylistDetail.route,
                arguments = listOf(navArgument(Dest.PlaylistDetail.ARG) { type = NavType.LongType })
            ) { entry ->
                val playlistId = entry.arguments?.getLong(Dest.PlaylistDetail.ARG) ?: return@composable
                PlaylistDetailScreen(container, playlistId = playlistId, onBack = ::back, onOpenPlayer = ::openPlayer)
            }
        }
    }
}
