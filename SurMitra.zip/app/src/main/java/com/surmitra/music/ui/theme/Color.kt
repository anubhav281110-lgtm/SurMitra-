package com.surmitra.music.ui.theme

import androidx.compose.ui.graphics.Color

// Anchor palette — identical to res/values/colors.xml, so the pre-Compose
// window background and the Compose UI never flash two different colors.
// Deep violet-black ink (not pure black), a vivid violet and an azure blue
// as the two accents the brief asked for, warm amber held back for a single
// job: marking what's currently playing or favourited, nothing else.
val SurmitraInk = Color(0xFF0E0B1A)
val SurmitraSurface = Color(0xFF18142C)
val SurmitraViolet = Color(0xFF8457FF)
val SurmitraAzure = Color(0xFF3E8EFF)
val SurmitraAmber = Color(0xFFFFB454)

// --- Dark scheme (the app's primary, default appearance) -------------------
val DarkSurfaceVariant = Color(0xFF241F3D)
val DarkSurfaceContainer = Color(0xFF211C38)
val DarkSurfaceContainerHigh = Color(0xFF2A2447)
val DarkOnPrimary = Color(0xFF160D30)
val DarkPrimaryContainer = Color(0xFF362A5E)
val DarkOnPrimaryContainer = Color(0xFFE9E1FF)
val DarkOnSecondary = Color(0xFF061527)
val DarkSecondaryContainer = Color(0xFF1C3A66)
val DarkOnSecondaryContainer = Color(0xFFD7E6FF)
val DarkOnTertiary = Color(0xFF2B1800)
val DarkTertiaryContainer = Color(0xFF4A3100)
val DarkOnTertiaryContainer = Color(0xFFFFDCA8)
val DarkOnSurface = Color(0xFFF3F0FA)
val DarkOnSurfaceVariant = Color(0xFFB3A9CC)
val DarkOutline = Color(0xFF3B3356)
val DarkOutlineVariant = Color(0xFF2A2440)
val DarkError = Color(0xFFFF6B6B)
val DarkOnError = Color(0xFF2B0A0A)
val DarkErrorContainer = Color(0xFF4A1515)
val DarkOnErrorContainer = Color(0xFFFFDAD6)

// --- Light scheme ("plus an optional light theme") -------------------------
val LightBackground = Color(0xFFFBF9FF)
val LightSurfaceVariant = Color(0xFFEDE7F7)
val LightPrimary = Color(0xFF6B4FD1)
val LightPrimaryContainer = Color(0xFFE7DEFF)
val LightOnPrimaryContainer = Color(0xFF230E6B)
val LightSecondary = Color(0xFF2F6FDB)
val LightSecondaryContainer = Color(0xFFD9E6FF)
val LightOnSecondaryContainer = Color(0xFF002451)
val LightTertiary = Color(0xFF9C6A00)
val LightTertiaryContainer = Color(0xFFFFDDA6)
val LightOnTertiaryContainer = Color(0xFF321F00)
val LightOnSurface = Color(0xFF1B1726)
val LightOnSurfaceVariant = Color(0xFF5C5470)
val LightOutline = Color(0xFF7C7390)
val LightError = Color(0xFFBA1A1A)
val LightErrorContainer = Color(0xFFFFDAD6)
val LightOnErrorContainer = Color(0xFF410002)
