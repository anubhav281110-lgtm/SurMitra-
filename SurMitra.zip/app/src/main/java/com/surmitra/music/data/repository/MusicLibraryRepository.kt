package com.surmitra.music.data.repository

import android.content.Context
import com.surmitra.music.data.local.MusicStoreScanner
import com.surmitra.music.data.model.Album
import com.surmitra.music.data.model.Artist
import com.surmitra.music.data.model.Genre
import com.surmitra.music.data.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** The on-device library: scanned once per app session (or on explicit rescan), kept in memory. */
class MusicLibraryRepository(context: Context) {
    private val scanner = MusicStoreScanner(context)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _hasScannedOnce = MutableStateFlow(false)
    val hasScannedOnce: StateFlow<Boolean> = _hasScannedOnce.asStateFlow()

    suspend fun rescan() {
        _isScanning.value = true
        _songs.value = scanner.scan()
        _hasScannedOnce.value = true
        _isScanning.value = false
    }

    fun albums(): List<Album> = _songs.value
        .groupBy { it.album to it.artist }
        .map { (key, songsInAlbum) ->
            val (albumTitle, artistName) = key
            Album(
                id = albumIdOf(albumTitle, artistName),
                title = albumTitle,
                artist = artistName,
                artUri = songsInAlbum.firstOrNull { it.albumArtUri != null }?.albumArtUri,
                songCount = songsInAlbum.size
            )
        }
        .sortedBy { it.title.lowercase() }

    fun artists(): List<Artist> = _songs.value
        .groupBy { it.artist }
        .map { (name, songsByArtist) -> Artist(id = artistIdOf(name), name = name, songCount = songsByArtist.size) }
        .sortedBy { it.name.lowercase() }

    fun genres(): List<Genre> = _songs.value
        .mapNotNull { it.genre }
        .groupingBy { it }
        .eachCount()
        .map { (name, count) -> Genre(name = name, songCount = count) }
        .sortedBy { it.name.lowercase() }

    fun songsForAlbum(albumId: String): List<Song> =
        _songs.value.filter { albumIdOf(it.album, it.artist) == albumId }

    fun songsForArtist(artistId: String): List<Song> =
        _songs.value.filter { artistIdOf(it.artist) == artistId }

    fun songsForGenre(genreName: String): List<Song> =
        _songs.value.filter { it.genre == genreName }

    fun search(query: String): List<Song> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        return _songs.value.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }
    }

    fun findById(id: String): Song? = _songs.value.firstOrNull { it.id == id }

    private fun albumIdOf(album: String, artist: String) = "album:$album:$artist"
    private fun artistIdOf(artist: String) = "artist:$artist"
}
