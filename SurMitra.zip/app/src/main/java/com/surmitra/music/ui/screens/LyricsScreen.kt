package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.surmitra.music.R
import com.surmitra.music.data.model.LyricsResult
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.EmptyState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsScreen(container: AppContainer, onBack: () -> Unit) {
    val playback by container.playerController.state.collectAsStateWithLifecycle()
    val song = playback.currentSong
    var lyrics by remember(song?.id) { mutableStateOf<LyricsResult>(LyricsResult.Loading) }

    LaunchedEffect(song?.id) {
        if (song == null) {
            lyrics = LyricsResult.NotFound
        } else {
            lyrics = LyricsResult.Loading
            lyrics = container.lyricsRepository.lyricsFor(song)
        }
    }

    val listState = rememberLazyListState()
    val currentLineIndex = remember(lyrics, playback.positionMs) {
        (lyrics as? LyricsResult.Synced)?.lines?.indexOfLast { it.timeMs <= playback.positionMs } ?: -1
    }
    LaunchedEffect(currentLineIndex) {
        if (currentLineIndex >= 0) listState.animateScrollToItem((currentLineIndex - 2).coerceAtLeast(0))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(song?.title ?: stringResource(R.string.now_playing), maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) } }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (val result = lyrics) {
                is LyricsResult.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                is LyricsResult.NotFound -> EmptyState(title = stringResource(R.string.empty_lyrics_title), modifier = Modifier.align(Alignment.Center))
                is LyricsResult.PlainOnly -> LazyColumn(Modifier.fillMaxSize().padding(24.dp)) {
                    itemsIndexed(result.text.lines()) { _, line -> Text(line, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(vertical = 2.dp)) }
                }
                is LyricsResult.Synced -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 140.dp, horizontal = 24.dp)
                ) {
                    itemsIndexed(result.lines) { index, line ->
                        val isCurrent = index == currentLineIndex
                        Text(
                            line.text.ifBlank { "♪" },
                            style = if (isCurrent) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium,
                            color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }
    }
}
