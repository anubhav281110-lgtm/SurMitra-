package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.surmitra.music.R
import com.surmitra.music.data.model.SourceSection
import com.surmitra.music.data.model.TrackSource
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.EmptyState
import com.surmitra.music.ui.components.SectionHeader
import com.surmitra.music.ui.components.SongRow
import com.surmitra.music.ui.components.sourceSectionTitle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    container: AppContainer,
    onOpenPlayer: () -> Unit,
    onOpenPlaylist: (Long) -> Unit,
    onOpenSettings: () -> Unit
) {
    val recentlyPlayed by container.playlistRepository.observeRecentlyPlayed(limit = 8)
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val librarySongs by container.musicLibraryRepository.songs.collectAsStateWithLifecycle()
    val isScanning by container.musicLibraryRepository.isScanning.collectAsStateWithLifecycle()
    val hasScannedOnce by container.musicLibraryRepository.hasScannedOnce.collectAsStateWithLifecycle()

    var trending by remember { mutableStateOf<List<SourceSection>>(emptyList()) }
    var loadingTrending by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        trending = container.onlineCatalogRepository.trending()
        container.rememberOnlineSongs(trending.flatMap { it.songs })
        loadingTrending = false
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings_title))
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (isScanning) {
                item {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
                }
            } else if (hasScannedOnce && librarySongs.isEmpty()) {
                item {
                    EmptyState(
                        title = stringResource(R.string.empty_library_title),
                        body = stringResource(R.string.empty_library_body)
                    )
                }
            }

            if (recentlyPlayed.isNotEmpty()) {
                item { SectionHeader(title = "Recently played") }
                items(recentlyPlayed, key = { "recent:" + it.id }) { song ->
                    SongRow(
                        song = song,
                        onClick = {
                            container.playAndRemember(recentlyPlayed, recentlyPlayed.indexOf(song))
                            onOpenPlayer()
                        }
                    )
                }
                item { Spacer(Modifier.height(8.dp)) }
            }

            when {
                loadingTrending -> item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                trending.isEmpty() -> item {
                    EmptyState(title = stringResource(R.string.error_network))
                }
                else -> trending.forEach { section ->
                    item { SectionHeader(title = sourceSectionTitle(section)) }
                    items(section.songs, key = { "trend:" + it.id }) { song ->
                        SongRow(
                            song = song,
                            onClick = {
                                container.playAndRemember(section.songs, section.songs.indexOf(song))
                                onOpenPlayer()
                            }
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}
