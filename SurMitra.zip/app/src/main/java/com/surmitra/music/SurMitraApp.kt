package com.surmitra.music

import android.app.Application
import com.surmitra.music.di.AppContainer

class SurMitraApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
