package com.surmitra.music.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.surmitra.music.R
import com.surmitra.music.di.AppContainer
import com.surmitra.music.ui.components.EmptyState
import com.surmitra.music.ui.components.SongRow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavouritesScreen(container: AppContainer, onOpenPlayer: () -> Unit) {
    val scope = rememberCoroutineScope()
    val favourites by container.playlistRepository.observeFavourites()
        .collectAsStateWithLifecycle(initialValue = emptyList())

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.nav_favourites)) }) }) { padding ->
        if (favourites.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding)) {
                EmptyState(
                    title = stringResource(R.string.empty_favourites_title),
                    body = stringResource(R.string.empty_favourites_body),
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding)) {
                items(favourites, key = { it.id }) { song ->
                    SongRow(
                        song = song,
                        onClick = {
                            container.playAndRemember(favourites, favourites.indexOf(song))
                            onOpenPlayer()
                        },
                        isFavourite = true,
                        onToggleFavourite = { scope.launch { container.playlistRepository.toggleFavourite(song) } }
                    )
                }
            }
        }
    }
}
