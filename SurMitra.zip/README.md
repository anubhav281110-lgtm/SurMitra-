# SurMitra

A native Android music player — Kotlin + Jetpack Compose + Material 3 — with a
local library player and two genuinely licensed online sources. This is a
complete, buildable Android Studio project, not a mock-up.

## Get it installed on your phone (≈5 minutes)

1. Install **Android Studio** (Koala or newer) if you don't have it — free, at
   developer.android.com/studio.
2. Unzip this project and open the folder in Android Studio (**File → Open**).
3. Let Gradle sync. Android Studio will offer to generate the Gradle wrapper
   if it's missing — accept that, or use Android Studio's own bundled Gradle.
4. *(Optional but recommended)* Get a **free** Jamendo client ID at
   https://devportal.jamendo.com (instant signup, no business approval) and
   paste it into `JAMENDO_CLIENT_ID=` in `gradle.properties`. The app builds
   and runs without it — Deezer charts/search/previews work immediately with
   no key at all — but Jamendo is the only source here with real full-length
   streaming, so it's worth the two minutes.
5. Plug in your phone (USB debugging on) or start an emulator, then
   **Run ▶**. That's a real installed APK on the device — Android Studio
   just did what `./gradlew installDebug` does under the hood.

## No computer — build it from your phone instead

Android Studio is desktop-only software; there's no phone version. If you
only have a phone, use GitHub Actions to build the APK in the cloud instead —
entirely from a browser, no install beyond a free GitHub account:

1. Go to **github.com**, sign up (free, just an email) if you don't have an
   account, then tap **New repository**. Name it `surmitra`, leave it
   Public, create it.
2. On the new repo's page, tap **uploading an existing file** and pick
   `SurMitra.zip` from your downloads. Commit it.
3. Tap **Add file → Create new file**. For the filename, type exactly
   `.github/workflows/build-apk.yml` (the slashes create the folders for
   you). Paste in the workflow below, then commit — this file is already
   included inside the zip too, for whenever you do have a computer.
4. Committing step 3 triggers the build automatically. Tap the **Actions**
   tab to watch it (~5 minutes).
5. When it's green, open that run, scroll to **Artifacts**, download
   `SurMitra-debug-apk`. It downloads as a `.zip` — extract it (most phone
   file managers do this natively) to get `app-debug.apk`.
6. Tap the APK to install. Android will ask permission to install from
   whatever app you downloaded it with, the first time only.

```yaml
name: Build SurMitra APK

on:
  push:
    branches: [ main ]
  workflow_dispatch: {}

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Check out repo
        uses: actions/checkout@v4
      - name: Unzip project
        run: if [ -f SurMitra.zip ]; then unzip -o SurMitra.zip -d .; fi
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v5
      - name: Build debug APK
        run: gradle assembleDebug --no-daemon
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: SurMitra-debug-apk
          path: app/build/outputs/apk/debug/*.apk
```

This builds on GitHub's own servers — your phone does none of the heavy
lifting. Every push to `main` rebuilds automatically after that, so updating
the APK later is just: upload a new zip (or edit files on github.dev, the
web editor GitHub offers from the repo page), wait, download, reinstall.

## With a computer: Android Studio

I built and wrote every file in this project, but I can't compile or run it
myself: this sandbox has no Android SDK, no Gradle, and no network access at
all (verified — DNS doesn't even resolve here). So step 5 above is the one
thing in this whole build I genuinely could not test. I read every file back
carefully and cross-checked every resource reference and API call this
project makes against itself, but Android Studio's own compiler is the first
real compile this code will see.

## What's real here, and what isn't

**The one thing worth knowing before anything else:** mainstream commercial
catalogs — JioSaavn, Gaana, Wynk, Spotify's or Apple Music's full catalog —
have no public API that lets an independent app stream their licensed
(Bollywood, major-label, etc.) music. That's not a gap in this code; it's a
business-licensing wall every indie dev hits, and the one place this spec's
"authorized providers only" instruction runs into reality. So "regional
Indian music" in the sense of mainstream film music isn't available through
any API I could legally wire up — I looked. What *is* real and working:

- **Jamendo** — a genuine licensed catalog of Creative-Commons-released
  music (independent and international artists), with real full-length
  streaming, trending, new releases, tag/genre search and curated radio
  stations. Free client ID, five-minute signup, no approval process. Its API
  also genuinely exposes a selectable stream format (`mp31`/`mp32`/`flac`) —
  Settings has a real Data Saver / Standard / Lossless control wired to it,
  not a cosmetic one, and it's correctly overridden down to Data Saver
  automatically whenever Data Saver is on and the device is off Wi-Fi.
- **Audius** — a second real, full-length, licensed catalog: a decentralised
  platform whose artists explicitly permit third-party API streaming. Free,
  keyless at this call volume. Skews independent/electronic/hip-hop rather
  than mainstream pop or film music, same as Jamendo in spirit but a
  genuinely different pool of artists and tracks.
- **Deezer** — charts, search, genre browsing and artwork/metadata for a much
  larger mainstream-adjacent catalog, no key needed at all — but only
  30-second previews, by Deezer's own design ("because of legal reasons we
  can't provide the audio file" — their developer FAQ), and no selectable
  quality on those previews. The app labels these clearly as previews; it
  never claims a preview is a full track.
- **LRCLIB** — free, keyless, time-synced lyrics, with local `.lrc` files
  next to a track as a fallback for your own library.
- **Your local library** — scan, play, playlists, favourites, play history,
  search, genres pulled from the real MediaStore genre table, embedded
  album art, a real `android.media.audiofx` equalizer (presets + manual
  bands + bass boost) that degrades honestly if a device doesn't expose one,
  background playback with lock-screen/notification controls via Media3's
  `MediaSessionService`, FLAC/WAV/MP3/OGG/M4A playback.

**On "high quality, full catalogs, licensed":** I looked at the other usual
names — SoundCloud now requires a paid Artist Pro subscription just to
register an API app (it was fully closed to new apps for years before that,
and access has fluctuated, so check developers.soundcloud.com yourself before
relying on it); Napster/7digital license full catalogs to apps, but as a paid
B2B contract, not a signup form; Qobuz/Tidal's hi-res catalogs aren't openly
available to indie apps either. None of those are wired in here — they're
either paid, or a business relationship, or both, which is a decision for you
to make deliberately rather than something I should quietly commit the app
to.

**Downloads are real, not a stub:** the download icon on the player (shown
only for Jamendo tracks the API itself marks `audiodownload_allowed`) fetches
that exact sanctioned URL, writes it to app-private storage, tracks progress
live, and plays back from the local file afterwards instead of streaming —
Settings shows how many tracks and how much space, with a remove-all action.
Wi-Fi-only downloads and Data Saver are both enforced for real against the
device's actual current network type, not just stored and ignored.

**Still deliberately not faked:** there's no selectable "320kbps" toggle for
Deezer, because its API has no such parameter — only Jamendo's does, which is
why only Jamendo gets a quality control. ALAC isn't included — Android has no
built-in decoder for it; it's reachable later via ExoPlayer's FFmpeg
extension if you need it. No custom typeface yet — the type scale is
deliberately tuned rather than left at Material defaults, but it's still the
system font.

## Project shape

```
app/src/main/java/com/surmitra/music/
  data/model        domain types (Song, Album, LyricsResult, CatalogResult…)
  data/local        Room database + the MediaStore scanner
  data/remote       Jamendo / Deezer / LRCLIB Retrofit interfaces
  data/repository   MusicLibrary, OnlineCatalog, Playlist, Lyrics, Settings,
                     Download (real offline downloads for Jamendo tracks)
  playback          ExoPlayer-backed MediaSessionService, MediaController
                     wrapper, and the real system equalizer
  di                AppContainer — one hand-rolled composition root, no
                     Hilt, so there's exactly one file to read to see how
                     everything is wired together
  ui/theme          Material 3 color scheme, type scale, shapes
  ui/navigation     bottom nav + the full nav graph
  ui/screens        Home, Explore, Search, Library, Favourites, Player,
                     Lyrics, Playlist detail, Settings
```

minSdk 26 · targetSdk/compileSdk 35 · Kotlin 2.0.21 · AGP 8.6.1 · Compose BOM
2024.10.01 · Media3 1.4.1 · Room 2.6.1. All pinned to specific versions I'm
confident exist and work together; Android Studio may still suggest newer
ones on sync, which is safe to accept.
